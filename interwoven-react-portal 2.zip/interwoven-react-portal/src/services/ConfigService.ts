
interface ConfigLinks {
  firstTimeLogin: string;
  applicationStatus: string;
  tokenActivation: string;
  allFaqs: string;
}

interface ContactInfo {
  [country: string]: {
    phone: string;
    hours: string;
  };
}

class ConfigService {
  private static links: ConfigLinks = {
    firstTimeLogin: 'https://www.ocbc.com/business-banking/help-and-support/business-internet-banking/login',
    applicationStatus: 'https://www.ocbc.com/business-banking/help-and-support/business-internet-banking/general',
    tokenActivation: 'https://www.ocbc.com/business-banking/help-and-support/business-internet-banking/uses-of-token',
    allFaqs: 'https://www.ocbc.com/business-banking/help-and-support'
  };

  private static contactInfo: ContactInfo = {
    sg: {
      phone: '+65 6538 1111',
      hours: 'Mon to Fri | 8:00AM - 8:00PM (excluding public holidays)'
    },
    my: {
      phone: '+60 3 8317 5000',
      hours: 'Mon to Fri | 8:00AM - 8:00PM (excluding public holidays)'
    },
    hk: {
      phone: '+852 2823 0228',
      hours: 'Mon to Fri | 8:00AM - 8:00PM (excluding public holidays)'
    }
  };

  static getLinks(): ConfigLinks {
    return this.links;
  }

  static getContactInfo(country: string) {
    return this.contactInfo[country.toLowerCase()] || this.contactInfo.sg;
  }

  static getBlockAccessEndpoint(country: string): string {
    return `http://localhost:8080/${country.toLowerCase()}/customer-security-corp/v1/block-access`;
  }
}

export default ConfigService;
