
import AppConfig from '../config/AppConfig';

class ProxyService {
  private static readonly PROXY_ENDPOINTS = {
    securityNotice: '/api/security-notice',
    needHelpContent: '/api/need-help-content'
  };

  static async fetchSecurityNotice(): Promise<string> {
    try {
      const config = AppConfig.getSecurityNoticeConfig();
      // Use proxy to fetch the text file content
      const proxyUrl = 'https://api.allorigins.win/raw?url=' + 
        encodeURIComponent(config.announcementUrl);
      
      const response = await fetch(proxyUrl, {
        method: 'GET',
        headers: {
          'Accept': 'text/plain,text/html,*/*'
        }
      });

      if (response.ok) {
        const textContent = await response.text();
        return textContent.trim();
      } else {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }
    } catch (error) {
      console.error('Proxy service error:', error);
      throw error;
    }
  }

  static async fetchNeedHelpContent(): Promise<string> {
    try {
      const config = AppConfig.getNeedHelpConfig();
      // Use proxy to fetch the text file content
      const proxyUrl = 'https://api.allorigins.win/raw?url=' + 
        encodeURIComponent(config.contentUrl);
      
      const response = await fetch(proxyUrl, {
        method: 'GET',
        headers: {
          'Accept': 'text/plain,text/html,*/*'
        }
      });

      if (response.ok) {
        const textContent = await response.text();
        return textContent.trim();
      } else {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }
    } catch (error) {
      console.error('Proxy service error for Need Help content:', error);
      throw error;
    }
  }
}

export default ProxyService;
