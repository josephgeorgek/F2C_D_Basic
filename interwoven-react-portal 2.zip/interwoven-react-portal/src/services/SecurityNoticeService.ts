
import AppConfig from '../config/AppConfig';
import ProxyService from './ProxyService';

class SecurityNoticeService {
  private static instance: SecurityNoticeService;
  private cachedNotice: string | null = null;
  private lastFetchTime: number = 0;
  private readonly CACHE_DURATION = 5 * 60 * 1000; // 5 minutes

  public static getInstance(): SecurityNoticeService {
    if (!SecurityNoticeService.instance) {
      SecurityNoticeService.instance = new SecurityNoticeService();
    }
    return SecurityNoticeService.instance;
  }

  async getSecurityNotice(language: string = 'en'): Promise<string> {
    const now = Date.now();
    
    // Return cached notice if it's still valid
    if (this.cachedNotice && (now - this.lastFetchTime) < this.CACHE_DURATION) {
      return this.cachedNotice;
    }

    try {
      console.log('Fetching security notice from Atlassian text file...');
      const textContent = await ProxyService.fetchSecurityNotice();
      
      if (textContent && textContent.length > 0) {
        this.cachedNotice = textContent;
        this.lastFetchTime = now;
        console.log('Successfully fetched security notice from text file');
        return textContent;
      }
    } catch (error) {
      console.warn('Failed to fetch security notice from Atlassian text file:', error);
    }

    // Fallback to local content
    console.log('Using fallback security notice');
    const config = AppConfig.getSecurityNoticeConfig();
    return config.fallbackNotice[language] || config.fallbackNotice.en;
  }

  // Method to force refresh the cache
  refreshCache(): void {
    this.cachedNotice = null;
    this.lastFetchTime = 0;
  }
}

export default SecurityNoticeService;
