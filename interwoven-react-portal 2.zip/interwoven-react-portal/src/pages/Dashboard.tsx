
import React, { useState, useEffect } from 'react';
import { LogOut, User, Building2, CreditCard, PieChart, TrendingUp, Bell, Settings, HelpCircle } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import BankLogo from '../components/BankLogo';
import LanguageToggle from '../components/LanguageToggle';
import { StorageUtils } from '../utils/storageUtils';

const Dashboard = () => {
  const [selectedLanguage, setSelectedLanguage] = useState(() => StorageUtils.getLanguage());
  const [selectedCountry] = useState(() => StorageUtils.getCountry());

  const handleLanguageChange = (language: string) => {
    setSelectedLanguage(language);
    StorageUtils.setLanguage(language);
  };

  const handleLogout = () => {
    // Clear any stored auth data
    localStorage.removeItem('authToken');
    localStorage.removeItem('userSession');
    // Redirect to login
    window.location.href = '/';
  };

  const texts = {
    en: {
      welcome: 'Welcome to Business Banking',
      dashboard: 'Dashboard',
      accountSummary: 'Account Summary',
      recentTransactions: 'Recent Transactions',
      quickActions: 'Quick Actions',
      totalBalance: 'Total Balance',
      availableBalance: 'Available Balance',
      pendingTransactions: 'Pending Transactions',
      transferFunds: 'Transfer Funds',
      payBills: 'Pay Bills',
      viewStatements: 'View Statements',
      manageUsers: 'Manage Users',
      accountSettings: 'Account Settings',
      help: 'Help & Support',
      logout: 'Logout',
      notifications: 'Notifications',
      noTransactions: 'No recent transactions',
      lastLogin: 'Last login',
      securityStatus: 'Security Status',
      active: 'Active'
    },
    zh: {
      welcome: '欢迎使用企业银行',
      dashboard: '仪表板',
      accountSummary: '账户摘要',
      recentTransactions: '最近交易',
      quickActions: '快速操作',
      totalBalance: '总余额',
      availableBalance: '可用余额',
      pendingTransactions: '待处理交易',
      transferFunds: '转账',
      payBills: '付款',
      viewStatements: '查看账单',
      manageUsers: '用户管理',
      accountSettings: '账户设置',
      help: '帮助与支持',
      logout: '退出',
      notifications: '通知',
      noTransactions: '暂无最近交易',
      lastLogin: '最后登录',
      securityStatus: '安全状态',
      active: '活跃'
    }
  };

  const currentTexts = texts[selectedLanguage] || texts.en;

  // Mock account data
  const accountData = {
    totalBalance: '1,234,567.89',
    availableBalance: '1,198,432.15',
    pendingTransactions: 3,
    currency: selectedCountry === 'sg' ? 'SGD' : selectedCountry === 'my' ? 'MYR' : 'USD'
  };

  const recentTransactions = [
    { id: 1, description: 'Salary Credit', amount: '+50,000.00', date: '2024-06-14', type: 'credit' },
    { id: 2, description: 'Office Rent Payment', amount: '-15,000.00', date: '2024-06-13', type: 'debit' },
    { id: 3, description: 'Supplier Payment', amount: '-8,750.00', date: '2024-06-12', type: 'debit' },
    { id: 4, description: 'Interest Credit', amount: '+125.50', date: '2024-06-11', type: 'credit' }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center gap-4">
              <BankLogo />
              <h1 className="text-xl font-semibold text-gray-900">{currentTexts.dashboard}</h1>
            </div>
            
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="sm">
                <Bell className="h-4 w-4" />
                <Badge variant="secondary" className="ml-1">3</Badge>
              </Button>
              <LanguageToggle
                value={selectedLanguage}
                onChange={handleLanguageChange}
              />
              <Button variant="outline" size="sm" onClick={handleLogout}>
                <LogOut className="h-4 w-4 mr-2" />
                {currentTexts.logout}
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-2">{currentTexts.welcome}</h2>
          <div className="flex items-center gap-4 text-sm text-gray-600">
            <span>{currentTexts.lastLogin}: June 15, 2024 at 10:30 AM</span>
            <Badge variant="outline" className="text-green-600 border-green-600">
              {currentTexts.securityStatus}: {currentTexts.active}
            </Badge>
          </div>
        </div>

        {/* Account Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">{currentTexts.totalBalance}</CardTitle>
              <PieChart className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{accountData.currency} {accountData.totalBalance}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">{currentTexts.availableBalance}</CardTitle>
              <CreditCard className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-600">{accountData.currency} {accountData.availableBalance}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">{currentTexts.pendingTransactions}</CardTitle>
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-orange-600">{accountData.pendingTransactions}</div>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Recent Transactions */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle>{currentTexts.recentTransactions}</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {recentTransactions.map((transaction) => (
                    <div key={transaction.id} className="flex justify-between items-center py-2 border-b last:border-b-0">
                      <div>
                        <p className="font-medium">{transaction.description}</p>
                        <p className="text-sm text-gray-500">{transaction.date}</p>
                      </div>
                      <div className={`font-semibold ${
                        transaction.type === 'credit' ? 'text-green-600' : 'text-red-600'
                      }`}>
                        {accountData.currency} {transaction.amount}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Quick Actions */}
          <div>
            <Card>
              <CardHeader>
                <CardTitle>{currentTexts.quickActions}</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <Button className="w-full" variant="outline">
                  <CreditCard className="h-4 w-4 mr-2" />
                  {currentTexts.transferFunds}
                </Button>
                <Button className="w-full" variant="outline">
                  <Building2 className="h-4 w-4 mr-2" />
                  {currentTexts.payBills}
                </Button>
                <Button className="w-full" variant="outline">
                  <PieChart className="h-4 w-4 mr-2" />
                  {currentTexts.viewStatements}
                </Button>
                <Button className="w-full" variant="outline">
                  <User className="h-4 w-4 mr-2" />
                  {currentTexts.manageUsers}
                </Button>
                <Button className="w-full" variant="outline">
                  <Settings className="h-4 w-4 mr-2" />
                  {currentTexts.accountSettings}
                </Button>
                <Button className="w-full" variant="outline">
                  <HelpCircle className="h-4 w-4 mr-2" />
                  {currentTexts.help}
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
};

export default Dashboard;
