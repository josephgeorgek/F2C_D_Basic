import React, { useState, useEffect } from 'react';
import { Eye, EyeOff, HelpCircle, Copyright } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { useNavigate } from 'react-router-dom';
import BankLogo from '../components/BankLogo';
import CountrySelector from '../components/CountrySelector';
import LanguageToggle from '../components/LanguageToggle';
import NeedHelpDialog from '../components/NeedHelpDialog';
import NewUserWizard from '../components/NewUserWizard';
import ResetPasswordWizard from '../components/ResetPasswordWizard';
import ContentService from '../services/ContentService';
import AuthService from '../services/AuthService';
import SecurityNoticeService from '../services/SecurityNoticeService';
import AppConfig from '../config/AppConfig';
import { StorageUtils } from '../utils/storageUtils';

const Index = () => {
  const navigate = useNavigate();
  const [selectedCountry, setSelectedCountry] = useState(() => StorageUtils.getCountry());
  const [selectedLanguage, setSelectedLanguage] = useState(() => StorageUtils.getLanguage());
  const [showPassword, setShowPassword] = useState(false);
  const [organizationId, setOrganizationId] = useState('');
  const [userId, setUserId] = useState('');
  const [password, setPassword] = useState('');
  const [needHelpOpen, setNeedHelpOpen] = useState(false);
  const [newUserWizardOpen, setNewUserWizardOpen] = useState(false);
  const [resetPasswordWizardOpen, setResetPasswordWizardOpen] = useState(false);
  const [announcement, setAnnouncement] = useState('');
  const [bannerContent, setBannerContent] = useState(null);
  const [backgroundImage, setBackgroundImage] = useState(AppConfig.getFallbackBackgroundUrl());
  const [isLoading, setIsLoading] = useState(false);
  const [showNeedHelpPopup, setShowNeedHelpPopup] = useState(false);
  const [securityNotice, setSecurityNotice] = useState('');

  const securityNoticeService = SecurityNoticeService.getInstance();

  useEffect(() => {
    loadContent();
    loadSecurityNotice();
    loadBackgroundImage();
  }, [selectedCountry, selectedLanguage]);

  const loadContent = async () => {
    try {
      const [announcementData, bannerData] = await Promise.all([
        ContentService.getAnnouncement(selectedCountry, selectedLanguage),
        ContentService.getBanner(selectedCountry, selectedLanguage)
      ]);
      setAnnouncement(announcementData);
      setBannerContent(bannerData);
    } catch (error) {
      console.error('Failed to load content:', error);
    }
  };

  const loadSecurityNotice = async () => {
    try {
      const notice = await securityNoticeService.getSecurityNotice(selectedLanguage);
      setSecurityNotice(notice);
    } catch (error) {
      console.error('Failed to load security notice:', error);
      // Fallback to default announcement
      const config = AppConfig.getSecurityNoticeConfig();
      setSecurityNotice(config.fallbackNotice[selectedLanguage] || config.fallbackNotice.en);
    }
  };

  const loadBackgroundImage = () => {
    const configuredUrl = AppConfig.getLoginBackgroundUrl();
    const fallbackUrl = AppConfig.getFallbackBackgroundUrl();
    
    // Test if the configured image loads
    const img = new Image();
    img.onload = () => {
      console.log('Using configured background image');
      setBackgroundImage(configuredUrl);
    };
    img.onerror = () => {
      console.warn('Failed to load configured background image, using fallback');
      setBackgroundImage(fallbackUrl);
    };
    img.src = configuredUrl;
  };

  const handleCountryChange = (country: string) => {
    setSelectedCountry(country);
    StorageUtils.setCountry(country);
  };

  const handleLanguageChange = (language: string) => {
    setSelectedLanguage(language);
    StorageUtils.setLanguage(language);
  };

  const handleLogin = async () => {
    setIsLoading(true);
    try {
      console.log('Logging in with:', { organizationId, userId, password, country: selectedCountry });
      const response = await AuthService.login({
        organizationId,
        userId,
        password,
        country: selectedCountry
      });
      
      // Store auth token and user session
      localStorage.setItem('authToken', response.token || 'mock-token');
      localStorage.setItem('userSession', JSON.stringify({
        organizationId,
        userId,
        country: selectedCountry,
        loginTime: new Date().toISOString()
      }));
      
      // Navigate to dashboard on successful login
      await new Promise(resolve => setTimeout(resolve, 1000));
      navigate('/dashboard');
    } catch (error) {
      console.error('Login failed:', error);
      // You can add error handling here (show error message, etc.)
    } finally {
      setIsLoading(false);
    }
  };

  const handleNeedHelp = () => {
    setShowNeedHelpPopup(true);
    setTimeout(() => {
      setShowNeedHelpPopup(false);
      setNeedHelpOpen(true);
    }, 2000);
  };

  const texts = {
    en: {
      welcomeTitle: 'Welcome to Business Banking',
      organizationId: 'Organisation ID',
      userId: 'User ID',
      password: 'Password',
      login: 'Login',
      resetPassword: 'Reset password or unlock account',
      activateNewUser: 'Activate new user access',
      needHelp: 'Need help?',
      securityAdvisory: 'Security advisory: Received a bulk order or service request from an organisation? Please independently verify the identity of the party you are corresponding with. Avoid making payment or deposits in advance to new suppliers.',
      learnHow: 'Learn how you can protect your business.',
      copyright: '© 2024 Redbank. All rights reserved.'
    },
    zh: {
      welcomeTitle: '欢迎使用企业银行',
      organizationId: '机构编号',
      userId: '用户编号',
      password: '密码',
      login: '登录',
      resetPassword: '重置密码或解锁账户',
      activateNewUser: '激活新用户访问',
      needHelp: '需要帮助？',
      securityAdvisory: '安全提醒：收到来自某机构的批量订单或服务请求？请独立验证您所对应方的身份。避免向新供应商提前付款或存款。',
      learnHow: '了解如何保护您的业务。',
      copyright: '© 2024 红银行。版权所有。'
    }
  };

  const currentTexts = texts[selectedLanguage] || texts.en;

  return (
    <div 
      className="min-h-screen bg-cover bg-center bg-no-repeat relative flex"
      style={{ 
        backgroundImage: `url('${backgroundImage}')`
      }}
    >
      {/* Security Advisory Banner - using fetched content */}
      {securityNotice && (
        <div className="absolute top-0 left-0 right-0 z-10">
          <Alert className="rounded-none border-amber-300 bg-amber-50 border-l-4 border-l-amber-500 py-2">
            <AlertDescription className="text-xs text-amber-800 leading-tight">
              {securityNotice}{' '}
              <a href="#" className="text-blue-600 hover:underline font-medium">
                {currentTexts.learnHow}
              </a>
            </AlertDescription>
          </Alert>
        </div>
      )}

      {/* Need Help Popup */}
      {showNeedHelpPopup && (
        <div className="fixed top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 z-50 bg-black bg-opacity-75 text-white px-6 py-3 rounded-lg">
          <p className="text-sm">Need help? Opening help dialog...</p>
        </div>
      )}

      {/* Copyright - Bottom Left */}
      <div className="absolute bottom-4 left-4 z-10">
        <div className="flex items-center gap-1 text-white text-sm opacity-80">
          <Copyright className="h-4 w-4" />
          <span>{currentTexts.copyright}</span>
        </div>
      </div>

      {/* Main Content Container - moved login to right, reduced width */}
      <div className="w-full flex justify-end items-center min-h-screen px-4 pr-20 pt-16">
        <div className="w-full max-w-sm bg-white rounded-lg shadow-lg p-6">
          {/* Header with Logo and Language */}
          <div className="flex justify-between items-center mb-6">
            <BankLogo />
            <LanguageToggle
              value={selectedLanguage}
              onChange={handleLanguageChange}
            />
          </div>

          {/* Welcome Title and Country Selector */}
          <div className="flex justify-between items-center mb-8">
            <h1 className="text-lg font-normal text-gray-900">
              {currentTexts.welcomeTitle}
            </h1>
            <CountrySelector 
              value={selectedCountry}
              onChange={handleCountryChange}
            />
          </div>

          {/* Login Form */}
          <form className="space-y-6" onSubmit={(e) => { e.preventDefault(); handleLogin(); }}>
            <div className="space-y-2">
              <Select value={organizationId} onValueChange={setOrganizationId}>
                <SelectTrigger className="h-12 text-base border-0 border-b-2 border-gray-300 rounded-none bg-transparent focus:border-gray-500">
                  <SelectValue placeholder={currentTexts.organizationId} />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="ACME001">ACME001</SelectItem>
                  <SelectItem value="CORP002">CORP002</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Input
                id="userId"
                type="text"
                value={userId}
                onChange={(e) => setUserId(e.target.value)}
                placeholder={currentTexts.userId}
                autoComplete="username"
                className="h-12 text-base border-0 border-b-2 border-gray-300 rounded-none bg-transparent focus:border-gray-500 placeholder:text-gray-500"
              />
            </div>

            <div className="space-y-2">
              <div className="relative">
                <Input
                  id="password"
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder={currentTexts.password}
                  autoComplete="current-password"
                  className="h-12 text-base border-0 border-b-2 border-gray-300 rounded-none bg-transparent focus:border-gray-500 placeholder:text-gray-500 pr-10"
                />
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent"
                  onClick={() => setShowPassword(!showPassword)}
                  aria-label="toggle password visibility"
                >
                  {showPassword ? <EyeOff className="h-5 w-5 text-gray-500" /> : <Eye className="h-5 w-5 text-gray-500" />}
                </Button>
              </div>
            </div>

            <div className="pt-4">
              <Button
                type="submit"
                className="w-24 h-10 bg-gray-600 hover:bg-gray-700 text-white text-sm font-normal rounded"
                disabled={isLoading}
              >
                {isLoading ? 'Logging in...' : currentTexts.login}
              </Button>
            </div>
          </form>

          {/* Links Section */}
          <div className="mt-8 space-y-3">
            <div className="flex items-center justify-between">
              <button
                type="button"
                className="text-blue-600 hover:text-blue-800 text-sm hover:underline"
                onClick={() => setResetPasswordWizardOpen(true)}
              >
                {currentTexts.resetPassword}
              </button>
            </div>
            
            <div className="flex items-center justify-between">
              <button
                type="button"
                className="text-blue-600 hover:text-blue-800 text-sm hover:underline"
                onClick={() => setNewUserWizardOpen(true)}
              >
                {currentTexts.activateNewUser}
              </button>
              
              <button
                type="button"
                className="flex items-center gap-2 text-gray-600 hover:text-gray-800 text-sm"
                onClick={handleNeedHelp}
              >
                <HelpCircle className="h-4 w-4" />
                {currentTexts.needHelp}
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Dialogs */}
      <NeedHelpDialog 
        open={needHelpOpen}
        onClose={() => setNeedHelpOpen(false)}
        language={selectedLanguage}
        country={selectedCountry}
      />
      <NewUserWizard
        open={newUserWizardOpen}
        onClose={() => setNewUserWizardOpen(false)}
        language={selectedLanguage}
      />
      <ResetPasswordWizard
        open={resetPasswordWizardOpen}
        onClose={() => setResetPasswordWizardOpen(false)}
        language={selectedLanguage}
      />
    </div>
  );
};

export default Index;
