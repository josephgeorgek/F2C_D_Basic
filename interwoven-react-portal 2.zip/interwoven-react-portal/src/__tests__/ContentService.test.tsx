
import ContentService from '../services/ContentService';
import axios from 'axios';

jest.mock('axios');
const mockedAxios = axios as jest.Mocked<typeof axios>;

describe('ContentService', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  describe('getBanner', () => {
    it('should successfully retrieve banner content for SG/EN', async () => {
      const mockResponse = {
        data: {
          title: 'Welcome to Business Banking',
          subtitle: 'Secure and reliable banking services',
          backgroundUrl: null,
          contentData: 'promotional banner content'
        }
      };
      
      mockedAxios.get.mockResolvedValueOnce(mockResponse);
      
      const result = await ContentService.getBanner('SG', 'EN');
      
      expect(result.title).toBe('Welcome to Business Banking');
      expect(result.subtitle).toBe('Secure and reliable banking services');
    });

    it('should successfully retrieve banner content for MY/ZH', async () => {
      const mockResponse = {
        data: {
          title: '欢迎使用企业银行',
          subtitle: '安全可靠的银行服务',
          backgroundUrl: null,
          contentData: '促销横幅内容'
        }
      };
      
      mockedAxios.get.mockResolvedValueOnce(mockResponse);
      
      const result = await ContentService.getBanner('MY', 'ZH');
      
      expect(result.title).toBe('欢迎使用企业银行');
      expect(result.subtitle).toBe('安全可靠的银行服务');
    });
  });

  describe('getBackgroundImage', () => {
    it('should retrieve background image URL for different countries', async () => {
      const mockResponse = {
        data: '/sg-business-bg.jpg'
      };
      
      mockedAxios.get.mockResolvedValueOnce(mockResponse);
      
      const result = await ContentService.getBackgroundImage('SG', 'EN');
      
      expect(result).toBe('/sg-business-bg.jpg');
    });
  });

  describe('getAnnouncement', () => {
    it('should retrieve security announcement for SG/EN', async () => {
      const mockResponse = {
        data: 'Security notice: Stay vigilant against fraudulent activities.'
      };
      
      mockedAxios.get.mockResolvedValueOnce(mockResponse);
      
      const result = await ContentService.getAnnouncement('SG', 'EN');
      
      expect(result).toContain('Security notice');
    });

    it('should retrieve security announcement for SG/ZH', async () => {
      const mockResponse = {
        data: '安全提醒：保持警惕，防范欺诈活动。'
      };
      
      mockedAxios.get.mockResolvedValueOnce(mockResponse);
      
      const result = await ContentService.getAnnouncement('SG', 'ZH');
      
      expect(result).toContain('安全提醒');
    });
  });

  describe('getLoginEndpoint', () => {
    it('should return correct endpoint for each country', () => {
      expect(ContentService.getLoginEndpoint('SG')).toBe('http://localhost:8080/sg/customer-security-corp/v1/orguserid-login');
      expect(ContentService.getLoginEndpoint('MY')).toBe('http://localhost:8080/my/customer-security-corp/v1/orguserid-login');
      expect(ContentService.getLoginEndpoint('HK')).toBe('http://localhost:8080/hk/customer-security-corp/v1/orguserid-login');
    });
  });
});
