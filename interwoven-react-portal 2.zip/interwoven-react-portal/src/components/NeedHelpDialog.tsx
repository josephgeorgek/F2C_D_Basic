
import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { X, AlertTriangle, Shield, ChevronDown, ChevronUp, ExternalLink } from 'lucide-react';
import { Separator } from '@/components/ui/separator';
import BlockAccessDialog from './BlockAccessDialog';
import ConfigService from '../services/ConfigService';
import NeedHelpContentService from '../services/NeedHelpContentService';

interface NeedHelpDialogProps {
  open: boolean;
  onClose: () => void;
  language: string;
  country: string;
}

interface HelpContent {
  en: {
    title: { text: string };
    fraudSupport: { text: string };
    reportFraud: { text: string };
    blockAccess: { text: string };
    faqs: { text: string };
    firstTimeLogin: { text: string; link: string };
    applicationStatus: { text: string; link: string };
    tokenActivation: { text: string; link: string };
    viewAllFaqs: { text: string; link: string };
    close: { text: string };
    call: { text: string };
  };
  zh: {
    title: { text: string };
    fraudSupport: { text: string };
    reportFraud: { text: string };
    blockAccess: { text: string };
    faqs: { text: string };
    firstTimeLogin: { text: string; link: string };
    applicationStatus: { text: string; link: string };
    tokenActivation: { text: string; link: string };
    viewAllFaqs: { text: string; link: string };
    close: { text: string };
    call: { text: string };
  };
  contactInfo: {
    [key: string]: {
      phone: string;
      hours: string;
    };
  };
}

const NeedHelpDialog: React.FC<NeedHelpDialogProps> = ({ open, onClose, language, country }) => {
  const [showFraudContact, setShowFraudContact] = useState(false);
  const [blockAccessOpen, setBlockAccessOpen] = useState(false);
  const [helpContent, setHelpContent] = useState<HelpContent | null>(null);
  const [isLoadingContent, setIsLoadingContent] = useState(false);

  useEffect(() => {
    if (open) {
      fetchHelpContent();
    }
  }, [open]);

  const fetchHelpContent = async () => {
    setIsLoadingContent(true);
    try {
      const content = await NeedHelpContentService.getInstance().getNeedHelpContent();
      if (content) {
        const parsedContent = JSON.parse(content) as HelpContent;
        setHelpContent(parsedContent);
        console.log('Fetched help content:', parsedContent);
      }
    } catch (error) {
      console.error('Failed to fetch help content:', error);
    } finally {
      setIsLoadingContent(false);
    }
  };

  // Fallback texts for when external content is not available
  const fallbackTexts = {
    en: {
      title: 'Need help?',
      fraudSupport: 'Fraud related support',
      reportFraud: 'Report fraud',
      blockAccess: 'Block access to account(s)',
      faqs: 'Frequently asked questions (FAQs)',
      firstTimeLogin: 'How to login to RedBank Velocity (web) and RedBank Business app (Mobile) for the first time?',
      applicationStatus: 'How do I check on the status of my application for RedBank Velocity?',
      tokenActivation: 'How do I activate my software token (RedBank QneToken) or hardware token?',
      viewAllFaqs: 'View all FAQs',
      close: 'Close',
      call: 'Call'
    },
    zh: {
      title: '需要帮助？',
      fraudSupport: '欺诈相关支持',
      reportFraud: '举报欺诈',
      blockAccess: '阻止账户访问',
      faqs: '常见问题 (FAQs)',
      firstTimeLogin: '如何首次登录红银行Velocity（网页）和红银行商业应用（移动）？',
      applicationStatus: '如何查看我的红银行Velocity申请状态？',
      tokenActivation: '如何激活我的软件令牌（红银行QneToken）or硬件令牌？',
      viewAllFaqs: '查看所有常见问题',
      close: '关闭',
      call: '致电'
    }
  };

  // Helper function to get text value from either string or object with text property
  const getText = (value: string | { text: string } | { text: string; link: string } | { phone: string; hours: string }): string => {
    if (typeof value === 'string') {
      return value;
    }
    if ('text' in value) {
      return value.text;
    }
    return '';
  };

  // Helper function to get link from object - updated to handle all possible types
  const getLink = (value: string | { text: string; link: string } | { phone: string; hours: string }): string => {
    if (typeof value === 'object' && 'link' in value) {
      return value.link;
    }
    return '';
  };

  const currentTexts = helpContent 
    ? helpContent[language as keyof typeof helpContent] || helpContent.en
    : fallbackTexts[language as keyof typeof fallbackTexts] || fallbackTexts.en;

  const contactInfo = helpContent?.contactInfo?.[country] || ConfigService.getContactInfo(country);
  const links = ConfigService.getLinks();

  const handleReportFraud = () => {
    setShowFraudContact(!showFraudContact);
  };

  const handleBlockAccess = () => {
    setBlockAccessOpen(true);
  };

  const handleExternalLink = (url: string) => {
    window.open(url, '_blank');
  };

  return (
    <>
      <Dialog open={open} onOpenChange={onClose}>
        <DialogContent className="max-w-md p-0 gap-0 font-sans">
          <DialogHeader className="bg-white border-b border-gray-200 p-4 rounded-t-lg relative">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <span className="text-red-600 font-bold text-lg">Redbank</span>
                <DialogTitle className="text-gray-900 font-normal text-lg">
                  {getText(currentTexts.title)}
                </DialogTitle>
              </div>
              <Button 
                onClick={onClose}
                variant="ghost"
                size="sm"
                className="text-gray-500 hover:bg-gray-100 h-6 w-6 p-0"
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
          </DialogHeader>

          <div className="p-0">
            {/* Fraud Support Section */}
            <div className="p-4 bg-red-50">
              <h3 className="text-sm font-semibold text-red-800 mb-3">
                {getText(currentTexts.fraudSupport)}
              </h3>
              <div className="space-y-2">
                <button 
                  onClick={handleReportFraud}
                  className="flex items-center justify-between w-full text-left p-2 hover:bg-red-100 rounded text-sm"
                >
                  <div className="flex items-center gap-3">
                    <AlertTriangle className="h-4 w-4 text-red-600" />
                    <span className="text-red-800">
                      {getText(currentTexts.reportFraud)}
                    </span>
                  </div>
                  {showFraudContact ? <ChevronUp className="h-4 w-4 text-red-600" /> : <ChevronDown className="h-4 w-4 text-red-600" />}
                </button>
                
                {showFraudContact && (
                  <div className="ml-7 p-3 bg-red-100 rounded text-sm text-red-800">
                    <p className="font-medium mb-1">
                      {getText(currentTexts.call)} {contactInfo.phone}
                    </p>
                    <p className="text-xs">{contactInfo.hours}</p>
                  </div>
                )}
                
                <button 
                  onClick={handleBlockAccess}
                  className="flex items-center gap-3 w-full text-left p-2 hover:bg-red-100 rounded text-sm"
                >
                  <Shield className="h-4 w-4 text-red-600" />
                  <span className="text-red-800">
                    {getText(currentTexts.blockAccess)}
                  </span>
                </button>
              </div>
            </div>

            <Separator />

            {/* Content Section */}
            {isLoadingContent ? (
              <div className="p-4 text-center">
                <span className="text-sm text-gray-500">Loading help content...</span>
              </div>
            ) : (
              <div className="p-4">
                <h3 className="text-sm font-semibold text-gray-900 mb-3">
                  {getText(currentTexts.faqs)}
                </h3>
                
                <div className="space-y-1">
                  <button 
                    onClick={() => handleExternalLink(getLink(currentTexts.firstTimeLogin) || links.firstTimeLogin)}
                    className="flex items-start justify-between w-full text-left p-2 hover:bg-gray-50 rounded group"
                  >
                    <span className="text-xs text-gray-700 leading-relaxed pr-2">
                      {getText(currentTexts.firstTimeLogin)}
                    </span>
                    <ExternalLink className="h-3 w-3 text-gray-400 group-hover:text-gray-600 mt-0.5 flex-shrink-0" />
                  </button>
                  
                  <button 
                    onClick={() => handleExternalLink(getLink(currentTexts.applicationStatus) || links.applicationStatus)}
                    className="flex items-start justify-between w-full text-left p-2 hover:bg-gray-50 rounded group"
                  >
                    <span className="text-xs text-gray-700 leading-relaxed pr-2">
                      {getText(currentTexts.applicationStatus)}
                    </span>
                    <ExternalLink className="h-3 w-3 text-gray-400 group-hover:text-gray-600 mt-0.5 flex-shrink-0" />
                  </button>
                  
                  <button 
                    onClick={() => handleExternalLink(getLink(currentTexts.tokenActivation) || links.tokenActivation)}
                    className="flex items-start justify-between w-full text-left p-2 hover:bg-gray-50 rounded group"
                  >
                    <span className="text-xs text-gray-700 leading-relaxed pr-2">
                      {getText(currentTexts.tokenActivation)}
                    </span>
                    <ExternalLink className="h-3 w-3 text-gray-400 group-hover:text-gray-600 mt-0.5 flex-shrink-0" />
                  </button>
                </div>

                <div className="mt-4 text-center">
                  <button 
                    onClick={() => handleExternalLink(getLink(currentTexts.viewAllFaqs) || links.allFaqs)}
                    className="text-blue-600 hover:text-blue-800 text-sm inline-flex items-center gap-1"
                  >
                    {getText(currentTexts.viewAllFaqs)}
                    <ExternalLink className="h-3 w-3" />
                  </button>
                </div>
              </div>
            )}

            <Separator />

            {/* Footer */}
            <div className="p-4 bg-gray-50">
              <Button onClick={onClose} className="w-full bg-gray-600 hover:bg-gray-700 text-white">
                {getText(currentTexts.close)}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      <BlockAccessDialog
        open={blockAccessOpen}
        onClose={() => setBlockAccessOpen(false)}
        language={language}
        country={country}
      />
    </>
  );
};

export default NeedHelpDialog;
