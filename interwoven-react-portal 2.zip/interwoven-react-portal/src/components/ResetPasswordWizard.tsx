import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { InputOTP, InputOTPGroup, InputOTPSlot } from '@/components/ui/input-otp';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { X, Check, Eye, EyeOff, AlertTriangle } from 'lucide-react';
import BankLogo from './BankLogo';

interface ResetPasswordWizardProps {
  open: boolean;
  onClose: () => void;
  language: string;
}

const ResetPasswordWizard: React.FC<ResetPasswordWizardProps> = ({ open, onClose, language }) => {
  const [activeStep, setActiveStep] = useState(0);
  const [organizationId, setOrganizationId] = useState('');
  const [userId, setUserId] = useState('');
  const [agreeTerms, setAgreeTerms] = useState(false);
  const [otpValue, setOtpValue] = useState('');
  const [otpError, setOtpError] = useState('');
  const [otpTimer, setOtpTimer] = useState(58);
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [passwordError, setPasswordError] = useState('');

  const texts = {
    en: {
      title: 'RESET PASSWORD OR UNLOCK ACCOUNT',
      subtitle: 'Enter your login credentials',
      description: 'We sent you an email containing your unique Organisation ID and User ID when your account was opened. Please check your registered email for these login credentials.',
      organizationId: 'Organisation ID',
      userId: 'User ID',
      agreeTerms: 'By clicking "Next", you confirm that you have read and understood, and agree to be bound by our Terms and Conditions.',
      back: 'Back',
      next: 'Next',
      steps: ['Login credentials', '2-step verification', 'Password reset'],
      verifyNumber: 'Verify number',
      otpDescription: 'Enter the 6-digit SMS One-Time Password (OTP) sent to +65 ****1234.',
      requestNewOtp: 'Request new OTP in',
      notYourNumber: 'Not your number? Give us the correct one by completing and mailing us the',
      applyForm: '"Apply and Manage OCBC Velocity" form',
      updateRecords: 'We will update our records within 7 working days of receiving the form.',
      createNewPassword: 'Create a new password',
      password: 'Password',
      reenterPassword: 'Re-enter password',
      mustContain: 'Must contain or be:',
      passwordRules: [
        '8 to 12 characters',
        '1 uppercase and 1 lowercase letter',
        '2 numeric characters',
        '1 special character',
        'Not identical to Organisation ID or User ID'
      ],
      passwordsDoNotMatch: 'Passwords do not match'
    },
    zh: {
      title: '重置密码或解锁账户',
      subtitle: '输入您的登录凭据',
      description: '当您开设账户时，我们向您发送了包含唯一机构ID和用户ID的电子邮件。请检查您注册的电子邮件以获取这些登录凭据。',
      organizationId: '机构编号',
      userId: '用户编号',
      agreeTerms: '点击"下一步"，即表示您确认已阅读并理解，并同意受我们的条款和条件约束。',
      back: '返回',
      next: '下一步',
      steps: ['登录凭据', '两步验证', '密码重置'],
      verifyNumber: '验证号码',
      otpDescription: '输入发送到+65 ****1234的6位SMS一次性密码(OTP)。',
      requestNewOtp: '重新申请OTP在',
      notYourNumber: '不是您的号码？请填写并邮寄给我们',
      applyForm: '"申请和管理OCBC Velocity"表格',
      updateRecords: '我们将在收到表格后7个工作日内更新我们的记录。',
      createNewPassword: '创建新密码',
      password: '密码',
      reenterPassword: '重新输入密码',
      mustContain: '必须包含或为：',
      passwordRules: [
        '8至12个字符',
        '1个大写字母和1个小写字母',
        '2个数字字符',
        '1个特殊字符',
        '不能与机构ID或用户ID相同'
      ],
      passwordsDoNotMatch: '密码不匹配'
    }
  };

  const currentTexts = texts[language] || texts.en;

  const validatePassword = (pwd: string) => {
    const rules = [
      { test: pwd.length >= 8 && pwd.length <= 12, message: '8 to 12 characters' },
      { test: /[A-Z]/.test(pwd) && /[a-z]/.test(pwd), message: '1 uppercase and 1 lowercase letter' },
      { test: (pwd.match(/\d/g) || []).length >= 2, message: '2 numeric characters' },
      { test: /[!@#$%^&*(),.?":{}|<>]/.test(pwd), message: '1 special character' },
      { test: pwd !== organizationId && pwd !== userId, message: 'Not identical to Organisation ID or User ID' }
    ];
    
    return rules;
  };

  const handleNext = () => {
    if (activeStep === 0) {
      // No validation for step 1, just proceed
      setActiveStep(activeStep + 1);
      return;
    }
    
    if (activeStep === 1) {
      if (otpValue.length !== 6) {
        setOtpError('OTP does not match what we have sent.');
        return;
      }
      setOtpError('');
    }
    
    if (activeStep === 2) {
      if (password !== confirmPassword) {
        setPasswordError(currentTexts.passwordsDoNotMatch);
        return;
      }
      const passwordRules = validatePassword(password);
      const failedRules = passwordRules.filter(rule => !rule.test);
      if (failedRules.length > 0) {
        setPasswordError('Password does not meet requirements');
        return;
      }
      setPasswordError('');
      // Complete the process
      onClose();
      return;
    }
    
    if (activeStep < 2) {
      setActiveStep(activeStep + 1);
    }
  };

  const handleBack = () => {
    if (activeStep > 0) {
      setActiveStep(activeStep - 1);
    }
  };

  const renderStepContent = () => {
    switch (activeStep) {
      case 0:
        return (
          <div className="flex-1 p-8">
            <h2 className="text-xl font-semibold mb-2">{currentTexts.subtitle}</h2>
            <p className="text-gray-600 mb-6">{currentTexts.description}</p>
            
            <div className="grid grid-cols-2 gap-6 mb-6">
              <div>
                <Label htmlFor="org-id" className="block text-sm font-medium mb-2">
                  {currentTexts.organizationId}
                </Label>
                <Input
                  id="org-id"
                  value={organizationId}
                  onChange={(e) => setOrganizationId(e.target.value)}
                  placeholder="EsolAlpha"
                  className="w-full"
                />
              </div>
              <div>
                <Label htmlFor="user-id" className="block text-sm font-medium mb-2">
                  {currentTexts.userId}
                </Label>
                <Input
                  id="user-id"
                  value={userId}
                  onChange={(e) => setUserId(e.target.value)}
                  placeholder="PeterAlpha"
                  className="w-full"
                />
              </div>
            </div>
            
            <div className="flex items-start space-x-2">
              <Checkbox
                id="terms"
                checked={agreeTerms}
                onCheckedChange={(checked) => setAgreeTerms(checked as boolean)}
                className="mt-1"
              />
              <Label htmlFor="terms" className="text-sm text-gray-600 leading-relaxed">
                {currentTexts.agreeTerms}
              </Label>
            </div>
          </div>
        );
        
      case 1:
        return (
          <div className="flex-1 p-8">
            <h2 className="text-xl font-semibold mb-2">{currentTexts.verifyNumber}</h2>
            <p className="text-gray-600 mb-8">{currentTexts.otpDescription}</p>
            
            <div className="flex justify-center mb-6">
              <InputOTP
                maxLength={6}
                value={otpValue}
                onChange={(value) => setOtpValue(value)}
              >
                <InputOTPGroup className="gap-2">
                  <InputOTPSlot index={0} className="w-12 h-12 bg-red-50 border-red-200 text-center" />
                  <InputOTPSlot index={1} className="w-12 h-12 bg-red-50 border-red-200 text-center" />
                  <InputOTPSlot index={2} className="w-12 h-12 bg-red-50 border-red-200 text-center" />
                  <InputOTPSlot index={3} className="w-12 h-12 bg-red-50 border-red-200 text-center" />
                  <InputOTPSlot index={4} className="w-12 h-12 bg-red-50 border-red-200 text-center" />
                  <InputOTPSlot index={5} className="w-12 h-12 bg-red-50 border-red-200 text-center" />
                </InputOTPGroup>
              </InputOTP>
            </div>
            
            {otpError && (
              <Alert className="border-red-200 bg-red-50 mb-4">
                <AlertTriangle className="h-4 w-4" />
                <AlertDescription className="text-red-800">
                  {otpError}
                </AlertDescription>
              </Alert>
            )}
            
            <p className="text-sm text-gray-600 mb-4">
              {currentTexts.requestNewOtp} 00:{otpTimer.toString().padStart(2, '0')}
            </p>
            
            <p className="text-sm text-gray-600">
              {currentTexts.notYourNumber}{' '}
              <a href="#" className="text-blue-600 hover:underline">
                {currentTexts.applyForm}
              </a>
              . {currentTexts.updateRecords}
            </p>
          </div>
        );
        
      case 2:
        const passwordRules = validatePassword(password);
        return (
          <div className="flex-1 p-8">
            <h2 className="text-xl font-semibold mb-6">{currentTexts.createNewPassword}</h2>
            
            <div className="space-y-6">
              <div>
                <Label htmlFor="password" className="block text-sm font-medium mb-2">
                  {currentTexts.password}
                </Label>
                <div className="relative">
                  <Input
                    id="password"
                    type={showPassword ? 'text' : 'password'}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full pr-10"
                  />
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    className="absolute right-0 top-0 h-full px-3"
                    onClick={() => setShowPassword(!showPassword)}
                  >
                    {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </Button>
                </div>
              </div>
              
              <div>
                <p className="text-sm font-medium mb-3">{currentTexts.mustContain}</p>
                <div className="space-y-2 mb-6">
                  {passwordRules.map((rule, index) => (
                    <div key={index} className="flex items-center space-x-2">
                      <Check className={`h-4 w-4 ${rule.test ? 'text-green-600' : 'text-gray-400'}`} />
                      <span className={`text-sm ${rule.test ? 'text-green-600' : 'text-gray-600'}`}>
                        {currentTexts.passwordRules[index]}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
              
              <div>
                <Label htmlFor="confirm-password" className="block text-sm font-medium mb-2">
                  {currentTexts.reenterPassword}
                </Label>
                <div className="relative">
                  <Input
                    id="confirm-password"
                    type={showConfirmPassword ? 'text' : 'password'}
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    className="w-full pr-10"
                  />
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    className="absolute right-0 top-0 h-full px-3"
                    onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                  >
                    {showConfirmPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </Button>
                </div>
              </div>
            </div>
            
            {passwordError && (
              <Alert className="border-red-200 bg-red-50 mt-4">
                <AlertTriangle className="h-4 w-4" />
                <AlertDescription className="text-red-800">
                  {passwordError}
                </AlertDescription>
              </Alert>
            )}
          </div>
        );
        
      default:
        return null;
    }
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl h-[80vh] p-0 gap-0 font-sans [&>button]:hidden">
        <DialogHeader className="bg-white border-l-4 border-l-red-600 p-6 flex flex-row items-center justify-between">
          <div className="flex items-center gap-4">
            <BankLogo />
            <DialogTitle className="text-lg font-semibold">{currentTexts.title}</DialogTitle>
          </div>
          <Button 
            onClick={onClose}
            variant="ghost"
            size="sm"
            className="text-gray-600 hover:bg-gray-100"
          >
            <X className="h-4 w-4" />
          </Button>
        </DialogHeader>

        <div className="flex flex-1">
          <div className="w-80 bg-gray-50 border-r border-gray-200 p-6">
            <div className="space-y-0 relative">
              {currentTexts.steps.map((step, index) => (
                <div key={index} className="relative">
                  <div className="flex items-center space-x-3 py-4">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium relative z-10 ${
                      index < activeStep 
                        ? 'bg-green-600 text-white' 
                        : index === activeStep 
                        ? 'bg-red-600 text-white' 
                        : 'bg-gray-200 text-gray-600'
                    }`}>
                      {index < activeStep ? <Check className="h-4 w-4" /> : index + 1}
                    </div>
                    <span className={`text-sm ${
                      index <= activeStep ? 'text-gray-900 font-medium' : 'text-gray-500'
                    }`}>
                      {step}
                    </span>
                  </div>
                  
                  {index < currentTexts.steps.length - 1 && (
                    <div className="absolute left-4 top-12 w-0.5 h-8 bg-gray-300"></div>
                  )}
                </div>
              ))}
            </div>
          </div>

          <div className="flex-1 flex flex-col">
            {renderStepContent()}
            
            <div className="border-t border-gray-200 p-6 flex justify-between bg-gray-50">
              <Button 
                onClick={handleBack}
                disabled={activeStep === 0}
                variant="outline"
                className="px-6"
              >
                {currentTexts.back}
              </Button>
              <Button 
                onClick={handleNext}
                className="bg-red-600 hover:bg-red-700 px-6"
              >
                {currentTexts.next}
              </Button>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default ResetPasswordWizard;
