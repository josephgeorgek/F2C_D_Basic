
package com.bank.regional.service;

import com.bank.regional.entity.User;
import com.bank.regional.model.LoginRequest;
import com.bank.regional.model.LoginResponse;
import com.bank.regional.repository.UserRepository;
import com.bank.regional.services.imp.AuthServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class AuthServiceTest {

    @Mock
    private UserRepository userRepository;

    @InjectMocks
    private AuthServiceImpl authService;

    private LoginRequest loginRequest;
    private User testUser;

    @BeforeEach
    void setUp() {
        loginRequest = new LoginRequest();
        loginRequest.setOrganisationId("ACME001");
        loginRequest.setUserId("testuser");
        loginRequest.setPassword("password123");

        testUser = new User();
        testUser.setId(1L);
        testUser.setOrganizationId("ACME001");
        testUser.setUserId("testuser");
        testUser.setPassword("password123");
        testUser.setCountry("SG");
        testUser.setActive(true);
        testUser.setBlocked(false);
    }

    @Test
    void authenticate_ValidCredentials_ReturnsSuccessResponse() {
        // Arrange
        when(userRepository.findByOrganizationIdAndUserIdAndCountry("ACME001", "testuser", "SG"))
                .thenReturn(Optional.of(testUser));

        // Act
        LoginResponse response = authService.authenticate(loginRequest, "SG");

        // Assert
        assertTrue(response.isSuccess());
        assertEquals("Login successful", response.getMessage());
        assertEquals("mock-jwt-token", response.getToken());
        assertEquals("SG", response.getCountry());
    }

    @Test
    void authenticate_InvalidPassword_ReturnsFailureResponse() {
        // Arrange
        testUser.setPassword("differentpassword");
        when(userRepository.findByOrganizationIdAndUserIdAndCountry("ACME001", "testuser", "SG"))
                .thenReturn(Optional.of(testUser));

        // Act
        LoginResponse response = authService.authenticate(loginRequest, "SG");

        // Assert
        assertFalse(response.isSuccess());
        assertEquals("Invalid credentials", response.getMessage());
        assertNull(response.getToken());
    }

    @Test
    void authenticate_UserNotFound_ReturnsFailureResponse() {
        // Arrange
        when(userRepository.findByOrganizationIdAndUserIdAndCountry("ACME001", "testuser", "SG"))
                .thenReturn(Optional.empty());

        // Act
        LoginResponse response = authService.authenticate(loginRequest, "SG");

        // Assert
        assertFalse(response.isSuccess());
        assertEquals("Invalid credentials", response.getMessage());
        assertNull(response.getToken());
    }

    @Test
    void authenticate_BlockedUser_ReturnsBlockedResponse() {
        // Arrange
        testUser.setBlocked(true);
        when(userRepository.findByOrganizationIdAndUserIdAndCountry("ACME001", "testuser", "SG"))
                .thenReturn(Optional.of(testUser));

        // Act
        LoginResponse response = authService.authenticate(loginRequest, "SG");

        // Assert
        assertFalse(response.isSuccess());
        assertEquals("User is blocked", response.getMessage());
        assertNull(response.getToken());
    }

    @Test
    void blockUser_ValidCredentials_BlocksUserSuccessfully() {
        // Arrange
        when(userRepository.findByOrganizationIdAndUserIdAndCountry("ACME001", "testuser", "SG"))
                .thenReturn(Optional.of(testUser));
        when(userRepository.save(any(User.class))).thenReturn(testUser);

        // Act
        LoginResponse response = authService.blockUser(loginRequest, "SG");

        // Assert
        assertTrue(response.isSuccess());
        assertEquals("User blocked successfully", response.getMessage());
        verify(userRepository).save(testUser);
        assertTrue(testUser.getBlocked());
    }

    @Test
    void blockUser_InvalidCredentials_ReturnsFailureResponse() {
        // Arrange
        testUser.setPassword("differentpassword");
        when(userRepository.findByOrganizationIdAndUserIdAndCountry("ACME001", "testuser", "SG"))
                .thenReturn(Optional.of(testUser));

        // Act
        LoginResponse response = authService.blockUser(loginRequest, "SG");

        // Assert
        assertFalse(response.isSuccess());
        assertEquals("User not found", response.getMessage());
        verify(userRepository, never()).save(any(User.class));
    }

    @Test
    void resetPassword_UserExists_ReturnsSuccessResponse() {
        // Arrange
        when(userRepository.findByOrganizationIdAndUserIdAndCountry("ACME001", "testuser", "SG"))
                .thenReturn(Optional.of(testUser));

        // Act
        LoginResponse response = authService.resetPassword("ACME001", "testuser", "SG");

        // Assert
        assertTrue(response.isSuccess());
        assertEquals("Password reset initiated", response.getMessage());
    }

    @Test
    void resetPassword_UserNotFound_ReturnsFailureResponse() {
        // Arrange
        when(userRepository.findByOrganizationIdAndUserIdAndCountry("ACME001", "testuser", "SG"))
                .thenReturn(Optional.empty());

        // Act
        LoginResponse response = authService.resetPassword("ACME001", "testuser", "SG");

        // Assert
        assertFalse(response.isSuccess());
        assertEquals("User not found", response.getMessage());
    }

    @Test
    void activateUser_UserExists_ReturnsSuccessResponse() {
        // Arrange
        when(userRepository.findByOrganizationIdAndUserIdAndCountry("ACME001", "testuser", "SG"))
                .thenReturn(Optional.of(testUser));

        // Act
        LoginResponse response = authService.activateUser("ACME001", "testuser", "SG");

        // Assert
        assertTrue(response.isSuccess());
        assertEquals("User activation initiated", response.getMessage());
    }

    @Test
    void activateUser_UserNotFound_ReturnsFailureResponse() {
        // Arrange
        when(userRepository.findByOrganizationIdAndUserIdAndCountry("ACME001", "testuser", "SG"))
                .thenReturn(Optional.empty());

        // Act
        LoginResponse response = authService.activateUser("ACME001", "testuser", "SG");

        // Assert
        assertFalse(response.isSuccess());
        assertEquals("User not found", response.getMessage());
    }

    @Test
    void authenticate_DifferentCountries_RoutesCorrectly() {
        // Test for Malaysia
        when(userRepository.findByOrganizationIdAndUserIdAndCountry("ACME001", "testuser", "MY"))
                .thenReturn(Optional.of(testUser));

        LoginResponse responseMY = authService.authenticate(loginRequest, "MY");
        assertTrue(responseMY.isSuccess());

        // Test for Hong Kong
        when(userRepository.findByOrganizationIdAndUserIdAndCountry("ACME001", "testuser", "HK"))
                .thenReturn(Optional.of(testUser));

        LoginResponse responseHK = authService.authenticate(loginRequest, "HK");
        assertTrue(responseHK.isSuccess());
    }

    @Test
    void authenticate_SpecialCharactersInPassword_HandledCorrectly() {
        // Arrange
        loginRequest.setPassword("P@ssw0rd!#$");
        testUser.setPassword("P@ssw0rd!#$");
        when(userRepository.findByOrganizationIdAndUserIdAndCountry("ACME001", "testuser", "SG"))
                .thenReturn(Optional.of(testUser));

        // Act
        LoginResponse response = authService.authenticate(loginRequest, "SG");

        // Assert
        assertTrue(response.isSuccess());
    }

    @Test
    void authenticate_LongOrganizationId_HandledCorrectly() {
        // Arrange
        String longOrgId = "VERYLONGORGANIZATIONIDENTIFIER12345";
        loginRequest.setOrganisationId(longOrgId);
        testUser.setOrganizationId(longOrgId);
        when(userRepository.findByOrganizationIdAndUserIdAndCountry(longOrgId, "testuser", "SG"))
                .thenReturn(Optional.of(testUser));

        // Act
        LoginResponse response = authService.authenticate(loginRequest, "SG");

        // Assert
        assertTrue(response.isSuccess());
    }

    @Test
    void authenticate_CaseSensitiveUserId_HandledCorrectly() {
        // Arrange
        loginRequest.setUserId("TestUser");
        when(userRepository.findByOrganizationIdAndUserIdAndCountry("ACME001", "TestUser", "SG"))
                .thenReturn(Optional.empty());

        // Act
        LoginResponse response = authService.authenticate(loginRequest, "SG");

        // Assert
        assertFalse(response.isSuccess());
        assertEquals("Invalid credentials", response.getMessage());
    }
}
