
package com.bank.regional.model;

import lombok.Data;

@Data
public class LoginRequest {
    private String organisationId;
    private String userId;
    private String password;
}
