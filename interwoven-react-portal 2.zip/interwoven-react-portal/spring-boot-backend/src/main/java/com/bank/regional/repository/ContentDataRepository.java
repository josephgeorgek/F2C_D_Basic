
package com.bank.regional.repository;

import com.bank.regional.entity.ContentData;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface ContentDataRepository extends JpaRepository<ContentData, Long> {
    Optional<ContentData> findByCountryAndLanguageAndContentType(String country, String language, String contentType);
}
