
package com.bank.regional.services;

import com.bank.regional.model.LoginRequest;
import com.bank.regional.model.LoginResponse;

public interface AuthService {
    LoginResponse authenticate(LoginRequest request, String country);
    LoginResponse resetPassword(String organizationId, String userId, String country);
    LoginResponse activateUser(String organizationId, String userId, String country);
    LoginResponse blockUser(LoginRequest request, String country);
}
