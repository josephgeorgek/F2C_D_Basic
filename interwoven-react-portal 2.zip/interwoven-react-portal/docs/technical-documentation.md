
# Technical Documentation - Regional Bank Business Banking Portal

## Table of Contents
1. [Technology Stack](#technology-stack)
2. [Architecture Overview](#architecture-overview)
3. [API Specifications](#api-specifications)
4. [Database Design](#database-design)
5. [Test Users and Mock Data](#test-users-and-mock-data)
6. [Fallback Mechanisms](#fallback-mechanisms)
7. [Configuration Management](#configuration-management)
8. [Development Setup](#development-setup)
9. [Testing Guide](#testing-guide)
10. [Deployment](#deployment)

## Technology Stack

### Frontend Technologies
- **React 18.3.1** - Core UI library with hooks and functional components
- **TypeScript 5.x** - Type-safe JavaScript development
- **Vite** - Fast build tool and development server
- **Tailwind CSS 3.x** - Utility-first CSS framework
- **Shadcn/UI** - Pre-built component library with Radix UI primitives
- **React Router DOM 6.26.2** - Client-side routing
- **Axios 1.9.0** - HTTP client for API requests
- **React Hook Form 7.53.0** - Form management with validation
- **Zod 3.23.8** - Schema validation
- **Tanstack React Query 5.56.2** - Data fetching and caching
- **Lucide React 0.462.0** - Icon library
- **Material-UI 6.4.11** - Additional UI components

### Backend Technologies
- **Spring Boot 3.x** - Java-based backend framework
- **Spring Web MVC** - REST API development
- **Spring Data JPA** - Database access layer
- **H2 Database** - In-memory database for development
- **Swagger/OpenAPI 3.0** - API documentation
- **Lombok** - Java boilerplate code reduction
- **Maven** - Build and dependency management

### Development Tools
- **Jest 29.7.0** - JavaScript testing framework
- **React Testing Library** - Component testing utilities
- **ESLint** - Code linting and formatting
- **PostCSS** - CSS processing

## Architecture Overview

### System Architecture
```
┌─────────────────┐    HTTP/REST    ┌─────────────────┐
│   React SPA     │◄───────────────►│  Spring Boot    │
│   (Frontend)    │                 │   (Backend)     │
└─────────────────┘                 └─────────────────┘
         │                                   │
         │                                   │
         ▼                                   ▼
┌─────────────────┐                 ┌─────────────────┐
│  Browser APIs   │                 │   H2 Database   │
│  - LocalStorage │                 │   (In-Memory)   │
│  - Fetch API    │                 └─────────────────┘
└─────────────────┘
```

### Component Architecture
```
src/
├── components/           # Reusable UI components
│   ├── ui/              # Shadcn/UI base components
│   ├── BankLogo.tsx     # Bank branding component
│   ├── CountrySelector.tsx
│   ├── LanguageToggle.tsx
│   ├── NeedHelpDialog.tsx
│   └── ...
├── pages/               # Route components
├── services/            # API and business logic
├── config/              # Configuration files
├── hooks/               # Custom React hooks
└── utils/               # Utility functions
```

## API Specifications

### Base URL
- **Development**: `http://localhost:8080`
- **Production**: `https://api.regionalbank.com`

### Authentication Endpoints

#### POST /{country}/customer-security-corp/v1/orguserid-login
**Description**: Corporate user authentication

**Path Parameters**:
- `country` (string): Country code (sg, my, hk, id, cn, vn, th)

**Request Body**:
```json
{
  "organisationId": "string (6-10 chars)",
  "userId": "string (4-20 chars)",
  "password": "string (8-50 chars)"
}
```

**Response Codes**:
- `200 OK`: Login successful
- `401 Unauthorized`: Invalid credentials
- `400 Bad Request`: Invalid input

**Success Response**:
```json
{
  "success": true,
  "message": "Login successful",
  "token": "jwt-token-string",
  "country": "sg"
}
```

**Error Response**:
```json
{
  "success": false,
  "message": "Invalid credentials",
  "token": null,
  "country": "sg"
}
```

#### POST /{country}/customer-security-corp/v1/block-access
**Description**: Block user account access

**Request/Response**: Similar to login endpoint

**Success Response**:
```json
{
  "status": "success",
  "message": "Your account is blocked with immediate effect"
}
```

#### POST /{country}/customer-security-corp/v1/password-reset
**Description**: Initiate password reset

**Request Body**:
```json
{
  "organizationId": "string",
  "userId": "string"
}
```

#### POST /{country}/customer-security-corp/v1/user-activation
**Description**: Activate new user account

**Request Body**:
```json
{
  "organizationId": "string",
  "userId": "string"
}
```

### Content Management Endpoints

#### GET /{country}/business/web/{language}/bfo/common/banner/banner_content.json
**Description**: Retrieve localized banner content

**Path Parameters**:
- `country`: Country code
- `language`: Language code (en, zh)

**Response**:
```json
{
  "title": "Welcome to Business Banking",
  "subtitle": "Secure and reliable banking services",
  "backgroundUrl": null,
  "content": "banner content data"
}
```

#### GET /{country}/business/web/{language}/bfo/common/images/background_image.json
**Description**: Get background image configuration

**Response**:
```json
{
  "title": null,
  "subtitle": null,
  "backgroundUrl": "/path/to/background.jpg",
  "content": "image metadata"
}
```

#### GET /{country}/business/web/{language}/bfo/prelogin/announcement/microsites/microsite_announcement.html
**Description**: Fetch security announcements

**Response**: Plain text or HTML content

### Error Response Format
All API endpoints follow consistent error formatting:
```json
{
  "errorCode": "SYSTEM-001",
  "message": "User-friendly error message",
  "details": "Technical details for debugging",
  "timestamp": "2024-01-01T00:00:00Z",
  "requestId": "unique-request-identifier"
}
```

## Database Design

### Entity Relationship Diagram (ERD)

```
┌─────────────────────┐         ┌─────────────────────┐
│       USERS         │         │   CONTENT_DATA      │
├─────────────────────┤         ├─────────────────────┤
│ id (PK)            │         │ id (PK)            │
│ organization_id     │         │ country            │
│ user_id            │         │ language           │
│ password           │         │ content_type       │
│ country            │         │ content_data       │
│ active             │         │ background_url     │
│ blocked            │         └─────────────────────┘
└─────────────────────┘
```

### Table Specifications

#### USERS Table
```sql
CREATE TABLE users (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    organization_id VARCHAR(10) NOT NULL,
    user_id VARCHAR(20) NOT NULL,
    password VARCHAR(255) NOT NULL,
    country VARCHAR(2) NOT NULL,
    active BOOLEAN DEFAULT TRUE,
    blocked BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY unique_user (organization_id, user_id, country)
);
```

#### CONTENT_DATA Table
```sql
CREATE TABLE content_data (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    country VARCHAR(2) NOT NULL,
    language VARCHAR(2) NOT NULL,
    content_type VARCHAR(20) NOT NULL,
    content_data TEXT,
    background_url VARCHAR(500),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY unique_content (country, language, content_type)
);
```

### Database Indexes
```sql
-- Performance indexes
CREATE INDEX idx_users_country ON users(country);
CREATE INDEX idx_users_org_user ON users(organization_id, user_id);
CREATE INDEX idx_content_country_lang ON content_data(country, language);
CREATE INDEX idx_content_type ON content_data(content_type);
```

## Test Users and Mock Data

### Test Users by Country

#### Singapore (SG)
```
Organization: ACME001, User: JOHNDOE, Password: password123
Organization: CORP002, User: JANESMITH, Password: password456
Organization: BANK003, User: ADMIN, Password: admin123
```

#### Malaysia (MY)
```
Organization: ACME001, User: AHMAD, Password: password123
Organization: CORP002, User: SITI, Password: password456
Organization: BANK003, User: RAHMAN, Password: admin123
```

#### Hong Kong (HK)
```
Organization: ACME001, User: WONG, Password: password123
Organization: CORP002, User: CHAN, Password: password456
Organization: BANK003, User: LEE, Password: admin123
```

#### Indonesia (ID)
```
Organization: ACME001, User: BUDI, Password: password123
Organization: CORP002, User: SARI, Password: password456
Organization: BANK003, User: INDRA, Password: admin123
```

#### China (CN)
```
Organization: ACME001, User: ZHANG, Password: password123
Organization: CORP002, User: LI, Password: password456
Organization: BANK003, User: WANG, Password: admin123
```

#### Vietnam (VN)
```
Organization: ACME001, User: NGUYEN, Password: password123
Organization: CORP002, User: TRAN, Password: password456
Organization: BANK003, User: LE, Password: admin123
```

#### Thailand (TH)
```
Organization: ACME001, User: SOMCHAI, Password: password123
Organization: CORP002, User: MALEE, Password: password456
Organization: BANK003, User: PANYA, Password: admin123
```

### Mock Content Data
```sql
-- Banner content
INSERT INTO content_data (country, language, content_type, content_data) VALUES
('SG', 'en', 'banner', 'Welcome to Singapore Business Banking'),
('SG', 'zh', 'banner', '欢迎使用新加坡企业银行'),
('MY', 'en', 'banner', 'Welcome to Malaysia Business Banking'),
-- ... additional entries for all countries
```

## Fallback Mechanisms

### 1. Content Service Fallbacks

#### Banner Content Fallback
```typescript
// Location: src/services/ContentService.ts
private getFallbackBanner(language: string): any {
  return {
    title: language === 'zh' ? '欢迎使用企业银行' : 'Welcome to Business Banking',
    subtitle: language === 'zh' ? '安全可靠的银行服务' : 'Secure and reliable banking services'
  };
}
```

#### Background Image Fallback
```typescript
private getFallbackBackgroundImage(): string {
  return '/lovable-uploads/6fffa759-a2a4-48dc-9970-6f351d662bb6.png';
}
```

#### Announcement Fallback
```typescript
private getFallbackAnnouncement(language: string): string {
  const fallbacks = {
    en: 'Security notice: Stay vigilant against fraudulent activities...',
    zh: '安全提醒：保持警惕，防范欺诈活动...'
  };
  return fallbacks[language] || fallbacks.en;
}
```

### 2. External Content Fallbacks

#### Security Notice Service
```typescript
// Location: src/services/SecurityNoticeService.ts
async getSecurityNotice(language: string = 'en'): Promise<string> {
  // Try external source first
  try {
    const textContent = await ProxyService.fetchSecurityNotice();
    if (textContent && textContent.length > 0) {
      return textContent;
    }
  } catch (error) {
    console.warn('External source failed, using fallback');
  }
  
  // Fallback to local content
  const config = AppConfig.getSecurityNoticeConfig();
  return config.fallbackNotice[language] || config.fallbackNotice.en;
}
```

### 3. Network Request Fallbacks

#### Axios Timeout Configuration
```typescript
// Default timeout: 5 seconds
const response = await axios.get(url, { 
  timeout: 5000,
  headers: {
    'Sec-Fetch-Site': 'same-origin',
    'Priority': 'u=4'
  }
});
```

### 4. Cache-Based Fallbacks

#### Content Caching Strategy
```typescript
private cachedContent: string | null = null;
private lastFetchTime: number = 0;
private readonly CACHE_DURATION = 5 * 60 * 1000; // 5 minutes

// Return cached content if available and valid
if (this.cachedContent && (now - this.lastFetchTime) < this.CACHE_DURATION) {
  return this.cachedContent;
}
```

## Configuration Management

### 1. Application Configuration

#### Location: `src/config/AppConfig.ts`

**Background Configuration**:
```typescript
class AppConfig {
  private static backgroundConfig: BackgroundConfig = {
    loginBackgroundUrl: 'https://github.com/josephgeorgek/F2C_D_Basic/blob/main/redbanklogin.png?raw=true',
    fallbackBackgroundUrl: '/lovable-uploads/6fffa759-a2a4-48dc-9970-6f351d662bb6.png'
  };
  
  // Methods to change configuration
  static updateBackgroundConfig(newConfig: BackgroundConfig) {
    this.backgroundConfig = { ...this.backgroundConfig, ...newConfig };
  }
}
```

**Security Notice Configuration**:
```typescript
private static securityNoticeConfig: SecurityNoticeConfig = {
  announcementUrl: 'https://pastebin.com/raw/qnQF3J9E',
  fallbackNotice: {
    en: 'Security advisory: Stay vigilant against fraudulent activities...',
    zh: '安全提醒：保持警惕，防范欺诈活动...'
  }
};
```

**Need Help Configuration**:
```typescript
private static needHelpConfig: NeedHelpConfig = {
  contentUrl: 'https://pastebin.com/raw/cTsdK7tX'
};
```

### 2. Service Configuration

#### Location: `src/services/ConfigService.ts`

**External Links Configuration**:
```typescript
private static links: ConfigLinks = {
  firstTimeLogin: 'https://www.ocbc.com/business-banking/help-and-support/business-internet-banking/login',
  applicationStatus: 'https://www.ocbc.com/business-banking/help-and-support/business-internet-banking/general',
  tokenActivation: 'https://www.ocbc.com/business-banking/help-and-support/business-internet-banking/uses-of-token',
  allFaqs: 'https://www.ocbc.com/business-banking/help-and-support'
};

// How to update links
static updateLinks(newLinks: Partial<ConfigLinks>) {
  this.links = { ...this.links, ...newLinks };
}
```

**Contact Information Configuration**:
```typescript
private static contactInfo: ContactInfo = {
  sg: { phone: '+65 6538 1111', hours: 'Mon to Fri | 8:00AM - 8:00PM' },
  my: { phone: '+60 3 8317 5000', hours: 'Mon to Fri | 8:00AM - 8:00PM' },
  hk: { phone: '+852 2823 0228', hours: 'Mon to Fri | 8:00AM - 8:00PM' }
};

// How to add new country contact info
static addCountryContact(country: string, contact: { phone: string; hours: string }) {
  this.contactInfo[country.toLowerCase()] = contact;
}
```

### 3. Backend Configuration

#### Location: `spring-boot-backend/src/main/resources/application.properties`

**Database Configuration**:
```properties
# H2 Database Configuration
spring.datasource.url=jdbc:h2:mem:testdb
spring.datasource.username=sa
spring.datasource.password=password

# To change to MySQL:
# spring.datasource.url=jdbc:mysql://localhost:3306/regionalbank
# spring.datasource.username=your_username
# spring.datasource.password=your_password
# spring.datasource.driver-class-name=com.mysql.cj.jdbc.Driver
```

**Server Configuration**:
```properties
# Server port (default: 8080)
server.port=8080

# To change port:
# server.port=9090
```

**JPA Configuration**:
```properties
# JPA Configuration
spring.jpa.hibernate.ddl-auto=none
spring.jpa.show-sql=true

# For production:
# spring.jpa.hibernate.ddl-auto=validate
# spring.jpa.show-sql=false
```

### 4. How to Change Configurations

#### Frontend Configuration Changes

**1. Update Background Images**:
```typescript
// In src/config/AppConfig.ts
AppConfig.updateBackgroundConfig({
  loginBackgroundUrl: 'https://your-new-image-url.com/image.jpg',
  fallbackBackgroundUrl: '/path/to/local/fallback.png'
});
```

**2. Update External URLs**:
```typescript
// In src/services/ConfigService.ts
ConfigService.updateLinks({
  firstTimeLogin: 'https://your-new-help-url.com',
  allFaqs: 'https://your-new-faq-url.com'
});
```

**3. Add New Country Support**:
```typescript
// 1. Add to ConfigService contact info
ConfigService.addCountryContact('ph', {
  phone: '+63 2 888 1234',
  hours: 'Mon to Fri | 9:00AM - 6:00PM'
});

// 2. Update ContentService to handle new country
// 3. Add test users in database
// 4. Update frontend country selector
```

#### Backend Configuration Changes

**1. Change Database**:
```properties
# In application.properties
spring.datasource.url=jdbc:postgresql://localhost:5432/regionalbank
spring.datasource.username=postgres
spring.datasource.password=your_password
spring.datasource.driver-class-name=org.postgresql.Driver
spring.jpa.database-platform=org.hibernate.dialect.PostgreSQLDialect
```

**2. Update Server Settings**:
```properties
# Change server port
server.port=9090

# Add SSL configuration
server.ssl.enabled=true
server.ssl.key-store=classpath:keystore.p12
server.ssl.key-store-password=your_password
```

**3. Environment-Specific Configurations**:
```properties
# Create application-dev.properties
spring.datasource.url=jdbc:h2:mem:testdb
spring.jpa.show-sql=true
logging.level.com.bank.regional=DEBUG

# Create application-prod.properties
spring.datasource.url=jdbc:mysql://prod-server:3306/regionalbank
spring.jpa.show-sql=false
logging.level.com.bank.regional=WARN
```

### 5. Configuration Best Practices

**1. Environment Variables**:
```bash
# Use environment variables for sensitive data
export DB_PASSWORD=your_secure_password
export JWT_SECRET=your_jwt_secret
export API_BASE_URL=https://api.prod.com
```

**2. Configuration Validation**:
```typescript
// Validate configuration on startup
class ConfigValidator {
  static validateAppConfig() {
    const config = AppConfig.getBackgroundConfig();
    if (!config.loginBackgroundUrl) {
      throw new Error('Login background URL is required');
    }
  }
}
```

**3. Dynamic Configuration Updates**:
```typescript
// Allow runtime configuration updates
class ConfigManager {
  static async updateFromRemote() {
    try {
      const remoteConfig = await fetch('/api/config');
      const config = await remoteConfig.json();
      AppConfig.updateBackgroundConfig(config.backgrounds);
    } catch (error) {
      console.warn('Failed to update remote config');
    }
  }
}
```

## Development Setup

### Prerequisites
- Node.js 16+ with npm/yarn
- Java 11+ with Maven
- Git

### Frontend Setup
```bash
# Install dependencies
npm install

# Start development server
npm run dev

# Run tests
npm test

# Build for production
npm run build
```

### Backend Setup
```bash
# Navigate to backend directory
cd spring-boot-backend

# Run the application
mvn spring-boot:run

# Run tests
mvn test

# Build JAR
mvn clean package
```

### Environment URLs
- **Frontend Dev**: http://localhost:5173
- **Backend Dev**: http://localhost:8080
- **Swagger UI**: http://localhost:8080/swagger-ui/index.html
- **H2 Console**: http://localhost:8080/h2-console

## Testing Guide

### Frontend Testing
```bash
# Unit tests with Jest
npm test

# Component tests with React Testing Library
npm run test:watch

# Coverage report
npm run test:coverage
```

### Backend Testing
```bash
# Unit tests
mvn test

# Integration tests
mvn verify

# Specific test class
mvn test -Dtest=ContentControllerTest
```

### API Testing
- **Postman Collection**: `spring-boot-backend/Regional-Bank-API.postman_collection.json`
- **Swagger UI**: Interactive testing at `/swagger-ui/index.html`

## Deployment

### Frontend Deployment
```bash
# Build production bundle
npm run build

# Deploy to static hosting (Netlify, Vercel, etc.)
# Upload dist/ folder contents
```

### Backend Deployment
```bash
# Create JAR file
mvn clean package

# Run in production
java -jar target/regional-bank-1.0.0.jar

# With production profile
java -jar -Dspring.profiles.active=prod target/regional-bank-1.0.0.jar
```

### Docker Deployment
```dockerfile
# Frontend Dockerfile
FROM node:18-alpine
WORKDIR /app
COPY package*.json ./
RUN npm ci --only=production
COPY . .
RUN npm run build
EXPOSE 5173
CMD ["npm", "run", "preview"]

# Backend Dockerfile
FROM openjdk:11-jre-slim
COPY target/*.jar app.jar
EXPOSE 8080
ENTRYPOINT ["java", "-jar", "/app.jar"]
```

---

*Document Version: 1.0*  
*Last Updated: 2025-06-14*  
*Maintained by: Development Team*
