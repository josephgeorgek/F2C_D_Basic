
# Technology Stack - Lovable Template

## Frontend Technologies
- **Framework**: React 18 with TypeScript
- **Build Tool**: Vite
- **Styling**: Tailwind CSS
- **UI Components**: Shadcn/UI
- **State Management**: React hooks + local storage
- **HTTP Client**: Axios
- **Routing**: React Router v6
- **Icons**: Lucide React

## Backend Technologies
- **Framework**: Spring Boot 3.x
- **Language**: Java 17+
- **Database**: H2 (in-memory) with PostgreSQL placeholder
- **API Documentation**: Swagger/OpenAPI
- **Build Tool**: Maven

## Project Structure

```
project-root/
├── src/                          # Frontend React application
│   ├── components/              # Reusable UI components
│   │   ├── ui/                 # Shadcn/UI components
│   │   ├── BankLogo.tsx        # Bank branding
│   │   ├── CountrySelector.tsx # Country selection
│   │   ├── LanguageToggle.tsx  # Language switching
│   │   ├── NeedHelpDialog.tsx  # Help and support
│   │   └── ...
│   ├── pages/                  # Route components
│   │   ├── Index.tsx          # Main login page
│   │   └── NotFound.tsx       # 404 page
│   ├── services/              # API services
│   │   ├── AuthService.ts     # Authentication
│   │   ├── ContentService.ts  # Content management
│   │   └── ConfigService.ts   # Configuration
│   └── utils/                 # Utility functions
├── spring-boot-backend/        # Backend Spring Boot app
│   ├── src/main/java/com/bank/regional/
│   │   ├── controller/        # REST controllers
│   │   ├── entity/           # JPA entities
│   │   ├── model/            # DTOs and models
│   │   ├── repository/       # Data repositories
│   │   └── services/         # Business logic
│   └── src/main/resources/
│       ├── application.properties
│       ├── schema.sql        # Database schema
│       └── data.sql          # Sample data
└── docs/                     # Documentation
```

## Dependencies

### Frontend Key Dependencies
```json
{
  "@tanstack/react-query": "^5.56.2",
  "axios": "^1.9.0",
  "react-router-dom": "^6.26.2",
  "react-hook-form": "^7.53.0",
  "zod": "^3.23.8",
  "tailwindcss": "^3.x",
  "lucide-react": "^0.462.0"
}
```

### Backend Key Dependencies
```xml
<dependencies>
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-web</artifactId>
    </dependency>
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-data-jpa</artifactId>
    </dependency>
    <dependency>
        <groupId>com.h2database</groupId>
        <artifactId>h2</artifactId>
        <scope>runtime</scope>
    </dependency>
</dependencies>
```
