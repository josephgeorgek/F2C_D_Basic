
# Quick Start Guide - Lovable Template

## Prerequisites
- Node.js 16+ and npm
- Java 17+ and Maven
- Modern web browser

## Setup Instructions

### 1. Frontend Setup
```bash
# Install dependencies
npm install

# Start development server
npm run dev
```

### 2. Backend Setup
```bash
# Navigate to backend directory
cd spring-boot-backend

# Run the application
mvn spring-boot:run
```

### 3. Access Points
- **Frontend**: http://localhost:5173
- **Backend API**: http://localhost:8080
- **Swagger UI**: http://localhost:8080/swagger-ui.html  
- **H2 Console**: http://localhost:8080/h2-console

## Environment Configuration

### Frontend (.env)
```env
VITE_API_BASE_URL=http://localhost:8080
```

### Backend (application.properties)
```properties
server.port=8080
spring.datasource.url=jdbc:h2:mem:testdb
spring.h2.console.enabled=true

# PostgreSQL placeholder (uncomment for production)
# spring.datasource.url=jdbc:postgresql://localhost:5432/regionalbank
# spring.datasource.username=your_username
# spring.datasource.password=your_password
```

## Test Users

### Default Test Credentials
```
Singapore (SG):
- Org: ACME001, User: JOHNDOE, Pass: password123
- Org: CORP002, User: JANESMITH, Pass: password456

Malaysia (MY):
- Org: ACME001, User: AHMAD, Pass: password123
- Org: CORP002, User: SITI, Pass: password456
```

## Testing

### Frontend
```bash
npm test              # Run tests
npm run test:coverage # Coverage report
```

### Backend
```bash
mvn test              # Unit tests
mvn integration-test  # Integration tests
```

## Deployment

### Frontend
```bash
npm run build         # Build for production
```

### Backend
```bash
mvn clean package     # Create JAR
java -jar target/regional-bank-*.jar
```

## Next Steps

1. Customize branding and styling
2. Add your specific business logic
3. Configure production database
4. Set up CI/CD pipeline
5. Add monitoring and logging
