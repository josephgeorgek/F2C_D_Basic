
# API Reference - Lovable Template

## Base Configuration

### URLs
- **Development**: `http://localhost:8080`
- **Production**: `https://api.yourbank.com`

### Authentication
All endpoints use organization-based authentication with JWT tokens.

## Core Endpoints

### Authentication API

#### POST /{country}/customer-security-corp/v1/orguserid-login
**Purpose**: Corporate user authentication

**Parameters**:
- `country`: Country code (sg, my, hk, id, cn, vn, th)

**Request**:
```json
{
  "organisationId": "ACME001",
  "userId": "JOHNDOE", 
  "password": "password123"
}
```

**Response**:
```json
{
  "success": true,
  "message": "Login successful",
  "token": "jwt-token-string",
  "country": "sg"
}
```

#### POST /{country}/customer-security-corp/v1/block-access
**Purpose**: Block user account

**Response**:
```json
{
  "status": "success",
  "message": "Your account is blocked with immediate effect"
}
```

#### POST /{country}/customer-security-corp/v1/password-reset
**Purpose**: Initiate password reset

**Request**:
```json
{
  "organizationId": "ACME001",
  "userId": "JOHNDOE"
}
```

#### POST /{country}/customer-security-corp/v1/user-activation
**Purpose**: Activate new user

**Request**:
```json
{
  "organizationId": "ACME001", 
  "userId": "NEWUSER"
}
```

### Content Management API

#### GET /{country}/business/web/{language}/bfo/common/banner/banner_content.json
**Purpose**: Retrieve localized banner content

**Response**:
```json
{
  "title": "Welcome to Business Banking",
  "subtitle": "Secure and reliable banking services",
  "backgroundUrl": null,
  "content": "banner content data"
}
```

#### GET /{country}/business/web/{language}/bfo/common/images/background_image.json
**Purpose**: Get background image configuration

**Response**:
```json
{
  "title": null,
  "subtitle": null, 
  "backgroundUrl": "/path/to/background.jpg",
  "content": "image metadata"
}
```

## Error Handling

### Standard Error Format
```json
{
  "errorCode": "SYSTEM-001",
  "message": "User-friendly error message", 
  "details": "Technical details",
  "timestamp": "2024-01-01T00:00:00Z",
  "requestId": "unique-identifier"
}
```

### Common Error Codes
- `AUTH-001`: Invalid credentials
- `AUTH-002`: Account blocked
- `SYSTEM-001`: Internal server error
- `VALIDATION-001`: Invalid input format

## Rate Limiting

- **Login attempts**: 5 per minute per IP
- **Content requests**: 100 per minute per IP
- **General API**: 1000 requests per hour per user

## CORS Configuration

### Allowed Origins
```java
@CrossOrigin(origins = {
    "http://localhost:5173",
    "https://yourapp.lovable.app",
    "https://yourdomain.com"
})
```

### Allowed Methods
- GET, POST, PUT, DELETE, OPTIONS

### Allowed Headers
- Content-Type, Authorization, X-Requested-With
