
# Comprehensive Development Prompt - Regional Bank Business Banking Application

## Project Overview

Create a complete business banking login application with the following core requirements:

### Application Type
Multi-country, multi-language business banking login portal with full-stack implementation using React frontend and Spring Boot backend.

### Core Functionality Requirements

#### 1. Authentication System
- **Login Process**: Organization ID + User ID + Password authentication
- **Multi-Country Support**: SG, MY, HK, ID, CN, VN, TH
- **Account Management**: Block access, password reset, new user activation
- **Security**: User blocking with immediate effect, credential validation

#### 2. User Interface Requirements
- **Responsive Design**: Mobile-first approach, desktop optimized
- **Language Support**: English and Chinese with dynamic switching
- **Country Selection**: Dropdown with country codes and flags
- **Background Images**: Dynamic, country-specific backgrounds
- **Form Design**: Clean, professional banking interface with:
  - Organization ID dropdown (ACME001, CORP002)
  - User ID text input
  - Password input with show/hide toggle
  - Login button with loading states

#### 3. Content Management System
- **Dynamic Content Loading**: Country and language-specific content
- **Content Types**: 
  - Banner content for promotions
  - Background images for branding
  - Security announcements and advisories
- **Fallback Mechanism**: Default content when specific locale unavailable
- **API Endpoints**: RESTful content delivery with JSON responses

#### 4. Help and Support System
- **Need Help Dialog** with three main sections:
  - **Report Fraud**: Expandable section showing localized contact numbers and hours
  - **Block Access**: Form-based account blocking with validation
  - **FAQ Section**: Links to external support resources
- **Contact Information**: Country-specific phone numbers and hours
- **External Links**: Configurable URLs for support resources

#### 5. User Workflows
- **Password Reset Wizard**: Multi-step process for password recovery
- **New User Activation**: Guided setup for first-time users
- **Account Blocking**: Self-service account security

### Technical Implementation Specifications

#### Frontend Stack Requirements
```typescript
// Required Technologies
- React 18 with TypeScript
- Vite for build tooling
- Tailwind CSS for styling
- Shadcn/UI component library
- React Router for navigation
- Axios for HTTP requests
- React Query for data fetching
```

#### Backend Stack Requirements
```java
// Required Technologies
- Spring Boot 3.x
- Java 17+
- H2 in-memory database
- JPA/Hibernate for data persistence
- Maven for dependency management
- Swagger for API documentation
- CORS configuration for frontend integration
```

#### Database Schema
```sql
-- Users table for authentication
CREATE TABLE users (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    organization_id VARCHAR(50) NOT NULL,
    user_id VARCHAR(50) NOT NULL,
    password VARCHAR(100) NOT NULL,
    country VARCHAR(5) NOT NULL,
    active BOOLEAN DEFAULT TRUE,
    blocked BOOLEAN DEFAULT FALSE
);

-- Content table for dynamic content
CREATE TABLE content_data (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    country VARCHAR(5) NOT NULL,
    language VARCHAR(5) NOT NULL,
    content_type VARCHAR(20) NOT NULL,
    content_data TEXT,
    background_url VARCHAR(500)
);
```

#### API Endpoint Structure
```
Authentication Endpoints:
POST /{country}/customer-security-corp/v1/orguserid-login
POST /{country}/customer-security-corp/v1/block-access
POST /{country}/password-reset
POST /{country}/user-activation

Content Endpoints:
GET /digital-content/{country}/business/web/{language}/bfo/common/banner/banner_content.json
GET /digital-content/{country}/business/web/{language}/bfo/common/background/background_image.json
GET /digital-content/{country}/business/web/{language}/bfo/common/announcement/announcement.json
```

### Component Architecture Requirements

#### 1. Page Components
- **Index.tsx**: Main login page (currently 297 lines - needs refactoring)
- **NotFound.tsx**: 404 error page

#### 2. Reusable Components
- **BankLogo**: Consistent branding component
- **CountrySelector**: Multi-country dropdown with flags
- **LanguageToggle**: EN/ZH language switching
- **NeedHelpDialog**: Comprehensive support interface
- **BlockAccessDialog**: Account blocking functionality
- **NewUserWizard**: Multi-step user onboarding
- **ResetPasswordWizard**: Password recovery flow

#### 3. Service Layer
```typescript
// AuthService - Authentication operations
interface AuthService {
  login(credentials: LoginCredentials): Promise<LoginResponse>;
  resetPassword(orgId: string, userId: string, country: string): Promise<any>;
  activateUser(orgId: string, userId: string, country: string): Promise<any>;
}

// ContentService - Dynamic content management
interface ContentService {
  getBanner(country: string, language: string): Promise<ContentResponse>;
  getBackgroundImage(country: string, language: string): Promise<string>;
  getAnnouncement(country: string, language: string): Promise<string>;
}

// ConfigService - Configuration management
interface ConfigService {
  getLinks(): ConfigLinks;
  getContactInfo(country: string): ContactInfo;
  getBlockAccessEndpoint(country: string): string;
}
```

### Business Logic Requirements

#### 1. Authentication Flow
```
1. User enters Organization ID, User ID, Password
2. System validates against database
3. If blocked user: Return "User is blocked" message
4. If valid: Return success with JWT token
5. If invalid: Return "Invalid credentials" message
```

#### 2. Account Blocking Flow
```
1. User enters credentials in block access form
2. System validates user exists
3. If found: Set blocked=true, return success message
4. If not found: Return error code ACLCORP-1018
5. Display appropriate UI message
```

#### 3. Content Loading Flow
```
1. Determine user's country and language
2. Fetch content from appropriate endpoints
3. Apply fallback for missing content
4. Cache content for performance
5. Update UI with localized content
```

### UI/UX Requirements

#### 1. Design Principles
- **Professional Banking Aesthetic**: Clean, trustworthy, modern
- **Accessibility**: WCAG 2.1 AA compliance
- **Responsive**: Mobile-first, tablet and desktop optimized
- **Performance**: Fast loading, minimal bundle size

#### 2. Layout Structure
```
Header: Logo + Language Toggle + Country Selector
Main: 
  - Security Banner (if announcements)
  - Login Form (right-aligned on desktop)
  - Background Image (dynamic, country-specific)
Footer: Copyright information
Dialogs: Help, Wizards, Blocking interface
```

#### 3. Form Design
- Organization ID: Dropdown with predefined options
- User ID: Text input with validation
- Password: Text input with show/hide toggle
- Login Button: Loading state with spinner
- Help Links: Below form, accessible design

### Error Handling Requirements

#### 1. Frontend Error Handling
- Network errors with retry options
- Validation errors with inline messages
- Loading states during API calls
- Graceful fallbacks for missing content

#### 2. Backend Error Handling
- Standardized error response format
- HTTP status codes for different error types
- Detailed error messages for debugging
- Input validation and sanitization

### Configuration Management

#### 1. Environment Configuration
```typescript
// Frontend configuration
interface Config {
  apiBaseUrl: string;
  defaultCountry: string;
  defaultLanguage: string;
  enableDebugMode: boolean;
}

// Backend configuration
interface BackendConfig {
  corsAllowedOrigins: string[];
  h2ConsoleEnabled: boolean;
  jwtSecretKey: string;
  tokenExpirationTime: number;
}
```

#### 2. External Links Configuration
All external URLs should be configurable through environment variables or configuration files, not hardcoded in components.

### Performance Requirements
- **First Paint**: < 2 seconds
- **Interactive**: < 3 seconds
- **Bundle Size**: < 1MB total
- **API Response**: < 500ms average

### Security Requirements
- Password field masking by default
- CORS properly configured
- Input validation on all forms
- SQL injection prevention
- XSS protection measures

### Testing Requirements
- Unit tests for all components
- Integration tests for API endpoints
- E2E tests for critical user flows
- Accessibility testing
- Performance testing

### Deployment Requirements
- Frontend: Static file hosting (Vercel, Netlify)
- Backend: Container deployment (Docker)
- Database: H2 for development, PostgreSQL for production
- Environment management for different stages

### Development Workflow
1. Set up Spring Boot backend with H2 database
2. Implement authentication endpoints
3. Create content management endpoints
4. Build React frontend with TypeScript
5. Implement authentication flow
6. Add content loading and localization
7. Build help and support features
8. Implement wizards and dialogs
9. Add comprehensive error handling
10. Optimize performance and accessibility
11. Add comprehensive testing
12. Document API and components

### Key Success Metrics
- Successfully authenticate users from multiple countries
- Dynamic content loading working for all locales
- Account blocking functionality operational
- Help system providing relevant information
- Responsive design working across devices
- Performance metrics meeting requirements
- Accessibility compliance achieved

This comprehensive prompt should enable recreation of the entire Regional Bank Business Banking application with all its current functionality and architecture.
