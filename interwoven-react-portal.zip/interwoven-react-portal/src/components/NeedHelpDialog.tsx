
import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { X, AlertTriangle, Shield, ChevronDown, ChevronUp, ExternalLink } from 'lucide-react';
import { Separator } from '@/components/ui/separator';
import BlockAccessDialog from './BlockAccessDialog';
import ConfigService from '../services/ConfigService';

interface NeedHelpDialogProps {
  open: boolean;
  onClose: () => void;
  language: string;
  country: string;
}

const NeedHelpDialog: React.FC<NeedHelpDialogProps> = ({ open, onClose, language, country }) => {
  const [showFraudContact, setShowFraudContact] = useState(false);
  const [blockAccessOpen, setBlockAccessOpen] = useState(false);

  const texts = {
    en: {
      title: 'Need help?',
      fraudSupport: 'Fraud related support',
      reportFraud: 'Report fraud',
      blockAccess: 'Block access to account(s)',
      faqs: 'Frequently asked questions (FAQs)',
      firstTimeLogin: 'How to login to RedBank Velocity (web) and RedBank Business app (Mobile) for the first time?',
      applicationStatus: 'How do I check on the status of my application for RedBank Velocity?',
      tokenActivation: 'How do I activate my software token (RedBank QneToken) or hardware token?',
      viewAllFaqs: 'View all FAQs',
      close: 'Close',
      call: 'Call'
    },
    zh: {
      title: '需要帮助？',
      fraudSupport: '欺诈相关支持',
      reportFraud: '举报欺诈',
      blockAccess: '阻止账户访问',
      faqs: '常见问题 (FAQs)',
      firstTimeLogin: '如何首次登录红银行Velocity（网页）和红银行商业应用（移动）？',
      applicationStatus: '如何查看我的红银行Velocity申请状态？',
      tokenActivation: '如何激活我的软件令牌（红银行QneToken）或硬件令牌？',
      viewAllFaqs: '查看所有常见问题',
      close: '关闭',
      call: '致电'
    }
  };

  const currentTexts = texts[language] || texts.en;
  const contactInfo = ConfigService.getContactInfo(country);
  const links = ConfigService.getLinks();

  const handleReportFraud = () => {
    setShowFraudContact(!showFraudContact);
  };

  const handleBlockAccess = () => {
    setBlockAccessOpen(true);
  };

  const handleExternalLink = (url: string) => {
    window.open(url, '_blank');
  };

  return (
    <>
      <Dialog open={open} onOpenChange={onClose}>
        <DialogContent className="max-w-md p-0 gap-0 font-sans">
          <DialogHeader className="bg-white border-b border-gray-200 p-4 rounded-t-lg relative">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <span className="text-red-600 font-bold text-lg">Redbank</span>
                <span className="text-gray-900 font-normal text-lg">{currentTexts.title}</span>
              </div>
              <Button 
                onClick={onClose}
                variant="ghost"
                size="sm"
                className="text-gray-500 hover:bg-gray-100 h-6 w-6 p-0"
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
          </DialogHeader>

          <div className="p-0">
            {/* Fraud Support Section */}
            <div className="p-4 bg-red-50">
              <h3 className="text-sm font-semibold text-red-800 mb-3">
                {currentTexts.fraudSupport}
              </h3>
              <div className="space-y-2">
                <button 
                  onClick={handleReportFraud}
                  className="flex items-center justify-between w-full text-left p-2 hover:bg-red-100 rounded text-sm"
                >
                  <div className="flex items-center gap-3">
                    <AlertTriangle className="h-4 w-4 text-red-600" />
                    <span className="text-red-800">{currentTexts.reportFraud}</span>
                  </div>
                  {showFraudContact ? <ChevronUp className="h-4 w-4 text-red-600" /> : <ChevronDown className="h-4 w-4 text-red-600" />}
                </button>
                
                {showFraudContact && (
                  <div className="ml-7 p-3 bg-red-100 rounded text-sm text-red-800">
                    <p className="font-medium mb-1">{currentTexts.call} {contactInfo.phone}</p>
                    <p className="text-xs">{contactInfo.hours}</p>
                  </div>
                )}
                
                <button 
                  onClick={handleBlockAccess}
                  className="flex items-center gap-3 w-full text-left p-2 hover:bg-red-100 rounded text-sm"
                >
                  <Shield className="h-4 w-4 text-red-600" />
                  <span className="text-red-800">{currentTexts.blockAccess}</span>
                </button>
              </div>
            </div>

            <Separator />

            {/* FAQs Section */}
            <div className="p-4">
              <h3 className="text-sm font-semibold text-gray-900 mb-3">
                {currentTexts.faqs}
              </h3>
              
              <div className="space-y-1">
                <button 
                  onClick={() => handleExternalLink(links.firstTimeLogin)}
                  className="flex items-start justify-between w-full text-left p-2 hover:bg-gray-50 rounded group"
                >
                  <span className="text-xs text-gray-700 leading-relaxed pr-2">
                    {currentTexts.firstTimeLogin}
                  </span>
                  <ExternalLink className="h-3 w-3 text-gray-400 group-hover:text-gray-600 mt-0.5 flex-shrink-0" />
                </button>
                
                <button 
                  onClick={() => handleExternalLink(links.applicationStatus)}
                  className="flex items-start justify-between w-full text-left p-2 hover:bg-gray-50 rounded group"
                >
                  <span className="text-xs text-gray-700 leading-relaxed pr-2">
                    {currentTexts.applicationStatus}
                  </span>
                  <ExternalLink className="h-3 w-3 text-gray-400 group-hover:text-gray-600 mt-0.5 flex-shrink-0" />
                </button>
                
                <button 
                  onClick={() => handleExternalLink(links.tokenActivation)}
                  className="flex items-start justify-between w-full text-left p-2 hover:bg-gray-50 rounded group"
                >
                  <span className="text-xs text-gray-700 leading-relaxed pr-2">
                    {currentTexts.tokenActivation}
                  </span>
                  <ExternalLink className="h-3 w-3 text-gray-400 group-hover:text-gray-600 mt-0.5 flex-shrink-0" />
                </button>
              </div>

              <div className="mt-4 text-center">
                <button 
                  onClick={() => handleExternalLink(links.allFaqs)}
                  className="text-blue-600 hover:text-blue-800 text-sm inline-flex items-center gap-1"
                >
                  {currentTexts.viewAllFaqs}
                  <ExternalLink className="h-3 w-3" />
                </button>
              </div>
            </div>

            <Separator />

            {/* Footer */}
            <div className="p-4 bg-gray-50">
              <Button onClick={onClose} className="w-full bg-gray-600 hover:bg-gray-700 text-white">
                {currentTexts.close}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      <BlockAccessDialog
        open={blockAccessOpen}
        onClose={() => setBlockAccessOpen(false)}
        language={language}
        country={country}
      />
    </>
  );
};

export default NeedHelpDialog;
