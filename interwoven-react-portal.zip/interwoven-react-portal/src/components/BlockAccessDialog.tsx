
import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { X } from 'lucide-react';
import { Alert, AlertDescription } from '@/components/ui/alert';
import axios from 'axios';
import ConfigService from '../services/ConfigService';

interface BlockAccessDialogProps {
  open: boolean;
  onClose: () => void;
  language: string;
  country: string;
}

const BlockAccessDialog: React.FC<BlockAccessDialogProps> = ({ open, onClose, language, country }) => {
  const [organizationId, setOrganizationId] = useState('');
  const [userId, setUserId] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  const texts = {
    en: {
      title: 'Block my access temporarily',
      description: 'You may request to block access of your user ID temporarily if you',
      reasons: [
        'have lost your mobile phone',
        'have lost your security token',
        'suspect unauthorised access to your account'
      ],
      organizationId: 'Organisation ID',
      userId: 'User ID',
      password: 'Password',
      cancel: 'Cancel',
      blockAccess: 'Block access',
      regainAccess: 'Regain access',
      regainDescription: 'Complete this form and mail it to us. You will be able to access OCBC Velocity account after 7 business days upon us receiving the form.',
      enquiries: 'For enquiries, please call +65 6538 1111 (Mon to Fri, 8:00AM - 8:00PM excluding public holidays)',
      incorrectDetails: 'Your login details are incorrect. Please check and try again.',
      blockedSuccess: 'Your account is blocked with immediate effect'
    },
    zh: {
      title: '暂时阻止我的访问',
      description: '如果您遇到以下情况，您可以请求暂时阻止您的用户ID访问',
      reasons: [
        '丢失了手机',
        '丢失了安全令牌',
        '怀疑账户遭到未授权访问'
      ],
      organizationId: '机构编号',
      userId: '用户编号',
      password: '密码',
      cancel: '取消',
      blockAccess: '阻止访问',
      regainAccess: '恢复访问',
      regainDescription: '完成此表格并邮寄给我们。在我们收到表格后的7个工作日内，您将能够访问OCBC Velocity账户。',
      enquiries: '如有查询，请致电+65 6538 1111（周一至周五，上午8:00 - 下午8:00，不包括公共假期）',
      incorrectDetails: '您的登录详细信息不正确。请检查并重试。',
      blockedSuccess: '您的账户已立即被阻止'
    }
  };

  const currentTexts = texts[language] || texts.en;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError('');
    setSuccess('');

    try {
      const endpoint = ConfigService.getBlockAccessEndpoint(country);
      const response = await axios.post(endpoint, {
        organisationId: organizationId,
        userId: userId,
        password: password
      });

      if (response.data.status === 'success') {
        setSuccess(currentTexts.blockedSuccess);
        setTimeout(() => {
          onClose();
          setOrganizationId('');
          setUserId('');
          setPassword('');
          setSuccess('');
        }, 3000);
      }
    } catch (error: any) {
      if (error.response?.status === 400) {
        setError(currentTexts.incorrectDetails);
      } else {
        setError('An error occurred. Please try again.');
      }
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-md p-0 gap-0 font-sans">
        <DialogHeader className="bg-white border-b border-gray-200 p-4 rounded-t-lg relative">
          <div className="flex items-center justify-between">
            <DialogTitle className="text-lg font-normal text-gray-900">
              {currentTexts.title}
            </DialogTitle>
            <Button 
              onClick={onClose}
              variant="ghost"
              size="sm"
              className="text-gray-500 hover:bg-gray-100 h-6 w-6 p-0"
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
        </DialogHeader>

        <div className="p-4">
          <p className="text-sm text-gray-700 mb-3">{currentTexts.description}</p>
          <ul className="text-sm text-gray-700 mb-6 space-y-1">
            {currentTexts.reasons.map((reason, index) => (
              <li key={index} className="flex items-start">
                <span className="mr-2">•</span>
                <span>{reason}</span>
              </li>
            ))}
          </ul>

          {error && (
            <Alert className="mb-4 border-red-200 bg-red-50">
              <AlertDescription className="text-red-700 text-sm">{error}</AlertDescription>
            </Alert>
          )}

          {success && (
            <Alert className="mb-4 border-green-200 bg-green-50">
              <AlertDescription className="text-green-700 text-sm">{success}</AlertDescription>
            </Alert>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <Label htmlFor="organizationId" className="text-sm text-gray-700">
                {currentTexts.organizationId}
              </Label>
              <Input
                id="organizationId"
                type="text"
                value={organizationId}
                onChange={(e) => setOrganizationId(e.target.value)}
                required
                className="mt-1"
              />
            </div>

            <div>
              <Label htmlFor="userId" className="text-sm text-gray-700">
                {currentTexts.userId}
              </Label>
              <Input
                id="userId"
                type="text"
                value={userId}
                onChange={(e) => setUserId(e.target.value)}
                required
                className="mt-1"
              />
            </div>

            <div>
              <Label htmlFor="password" className="text-sm text-gray-700">
                {currentTexts.password}
              </Label>
              <Input
                id="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                className="mt-1"
              />
            </div>

            <div className="flex gap-2 pt-2">
              <Button
                type="button"
                variant="outline"
                onClick={onClose}
                className="flex-1"
              >
                {currentTexts.cancel}
              </Button>
              <Button
                type="submit"
                disabled={isLoading}
                className="flex-1 bg-gray-600 hover:bg-gray-700"
              >
                {isLoading ? '...' : currentTexts.blockAccess}
              </Button>
            </div>
          </form>

          <div className="mt-6 p-3 bg-yellow-50 rounded">
            <h4 className="font-semibold text-sm text-gray-900 mb-2">{currentTexts.regainAccess}</h4>
            <p className="text-xs text-gray-700 mb-2">{currentTexts.regainDescription}</p>
            <p className="text-xs text-gray-700">{currentTexts.enquiries}</p>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default BlockAccessDialog;
