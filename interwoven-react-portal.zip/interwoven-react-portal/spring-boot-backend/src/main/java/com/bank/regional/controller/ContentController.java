
package com.bank.regional.controller;

import com.bank.regional.model.ContentResponse;
import com.bank.regional.services.ContentService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/digital-content")
@CrossOrigin(origins = "*")
@Tag(name = "Content", description = "Content management APIs for localized banking content")
public class ContentController {

    @Autowired
    private ContentService contentService;

    @Operation(summary = "Get Banner Content", description = "Retrieve localized banner content for specific country and language")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Banner content retrieved successfully", 
                        content = @Content(mediaType = "application/json", schema = @Schema(implementation = ContentResponse.class))),
            @ApiResponse(responseCode = "404", description = "Content not found", content = @Content),
            @ApiResponse(responseCode = "400", description = "Bad request", content = @Content)
    })
    @GetMapping("/{country}/business/web/{language}/bfo/common/banner/banner_content.json")
    public ResponseEntity<ContentResponse> getBannerContent(
            @Parameter(description = "Country code (sg, my, hk, id, cn, vn, th)", example = "sg") 
            @PathVariable String country,
            @Parameter(description = "Language code (en, zh)", example = "en") 
            @PathVariable String language) {
        
        ContentResponse content = contentService.getBanner(country, language);
        return content != null ? ResponseEntity.ok(content) : ResponseEntity.notFound().build();
    }

    @Operation(summary = "Get Background Image", description = "Retrieve localized background image configuration")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Background image data retrieved successfully", 
                        content = @Content(mediaType = "application/json", schema = @Schema(implementation = ContentResponse.class))),
            @ApiResponse(responseCode = "404", description = "Content not found", content = @Content),
            @ApiResponse(responseCode = "400", description = "Bad request", content = @Content)
    })
    @GetMapping("/{country}/business/web/{language}/bfo/common/images/background_image.json")
    public ResponseEntity<ContentResponse> getBackgroundImage(
            @Parameter(description = "Country code (sg, my, hk, id, cn, vn, th)", example = "sg") 
            @PathVariable String country,
            @Parameter(description = "Language code (en, zh)", example = "en") 
            @PathVariable String language) {
        
        ContentResponse content = contentService.getBackgroundImage(country, language);
        return content != null ? ResponseEntity.ok(content) : ResponseEntity.notFound().build();
    }

    @Operation(summary = "Get Announcement Content", description = "Retrieve localized announcement content in HTML format")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Announcement content retrieved successfully", 
                        content = @Content(mediaType = "text/html")),
            @ApiResponse(responseCode = "404", description = "Content not found", content = @Content),
            @ApiResponse(responseCode = "400", description = "Bad request", content = @Content)
    })
    @GetMapping("/{country}/business/web/{language}/bfo/prelogin/announcement/microsites/microsite_announcement.html")
    public ResponseEntity<String> getAnnouncementContent(
            @Parameter(description = "Country code (sg, my, hk, id, cn, vn, th)", example = "sg") 
            @PathVariable String country,
            @Parameter(description = "Language code (en, zh)", example = "en") 
            @PathVariable String language) {
        
        String content = contentService.getAnnouncement(country, language);
        return content != null ? ResponseEntity.ok(content) : ResponseEntity.notFound().build();
    }
}
