
# Testing Guide

## Running Tests

Since the package.json cannot be directly modified in this environment, here are the available ways to run tests:

### Option 1: Using npx directly
```bash
npx jest
```

### Option 2: Using the test runner script (ES Module)
```bash
node run-tests.js
```

### Option 3: Running specific test files
```bash
npx jest src/__tests__/Index.test.tsx
```

### Option 4: Running tests in watch mode
```bash
npx jest --watch
```

### Option 5: Running tests with coverage
```bash
npx jest --coverage
```

## Test Configuration

The tests are configured using:
- **Jest** as the test runner with ES module support
- **@testing-library/react** for component testing
- **@testing-library/jest-dom** for additional matchers
- **jsdom** as the test environment
- **ts-jest** for TypeScript support

## Important Notes

1. The project uses ES modules, so the test runner script (`run-tests.js`) uses `import` syntax instead of `require`
2. Jest is configured to handle both TypeScript and ES modules
3. All browser APIs (IntersectionObserver, ResizeObserver, matchMedia) are properly mocked

## Available Test Commands

| Command | Description |
|---------|-------------|
| `npx jest` | Run all tests once |
| `npx jest --watch` | Run tests in watch mode |
| `npx jest --coverage` | Run tests with coverage report |
| `npx jest --verbose` | Run tests with verbose output |
| `node run-tests.js` | Run tests using the custom ES module script |

## Test Structure

Tests are located in:
- `src/__tests__/` - Main test directory
- Files ending with `.test.tsx` or `.spec.tsx`

## Dependencies

The application now includes proper MUI dependencies:
- `@mui/material` - Material-UI components
- `@mui/icons-material` - Material-UI icons
- `@emotion/react` and `@emotion/styled` - Required for MUI styling

## Example Test Run

```bash
$ node run-tests.js

Running tests...
 PASS  src/__tests__/Index.test.tsx
  Index Page
    ✓ renders welcome title (234ms)
    ✓ renders login form fields (45ms)
    ✓ opens need help dialog when clicked (67ms)
    ✓ toggles password visibility (23ms)
    ✓ switches language (34ms)

Test Suites: 1 passed, 1 total
Tests:       5 passed, 5 total
Snapshots:   0 total
Time:        2.456s
```

## Troubleshooting

If you encounter issues:

1. **ES Module errors**: Make sure you're using `node run-tests.js` (ES module syntax) instead of CommonJS require
2. **Missing dependencies**: The MUI dependencies should now be properly installed
3. **TypeScript errors**: Check that all imported components exist and types are correct
4. **Test failures**: Check console output for specific error messages

## Mock Information

The tests include mocks for:
- ContentService API calls
- UI components (BankLogo, CountrySelector, etc.)
- Browser APIs (matchMedia, IntersectionObserver, ResizeObserver)
- MUI components and icons
