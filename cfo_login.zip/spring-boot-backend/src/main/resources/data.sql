
-- Insert test users for each country
INSERT INTO users (organization_id, user_id, password, country, active) VALUES
('ACME001', 'JOHNDOE', 'password123', 'SG', true),
('CORP002', 'JANESMITH', 'password456', 'SG', true),
('ACME001', 'AHMAD', 'password123', 'MY', true),
('CORP002', 'SITI', 'password456', 'MY', true),
('ACME001', 'WONG', 'password123', 'HK', true),
('CORP002', 'CHAN', 'password456', 'HK', true),
('ACME001', 'BUDI', 'password123', 'ID', true),
('CORP002', 'SARI', 'password456', 'ID', true),
('ACME001', 'ZHANG', 'password123', 'CN', true),
('CORP002', 'LI', 'password456', 'CN', true),
('ACME001', 'NGUYEN', 'password123', 'VN', true),
('CORP002', 'TRAN', 'password456', 'VN', true),
('ACME001', 'SOMCHAI', 'password123', 'TH', true),
('CORP002', 'MALEE', 'password456', 'TH', true);

-- Insert content data for banners
INSERT INTO content_data (country, language, content_type, content_data, background_url) VALUES
('SG', 'en', 'banner', '{"title":"Welcome to Singapore Banking","subtitle":"Secure and reliable banking services"}', null),
('SG', 'zh', 'banner', '{"title":"欢迎使用新加坡银行","subtitle":"安全可靠的银行服务"}', null),
('MY', 'en', 'banner', '{"title":"Welcome to Malaysia Banking","subtitle":"Secure and reliable banking services"}', null),
('MY', 'zh', 'banner', '{"title":"欢迎使用马来西亚银行","subtitle":"安全可靠的银行服务"}', null),
('HK', 'en', 'banner', '{"title":"Welcome to Hong Kong Banking","subtitle":"Secure and reliable banking services"}', null),
('HK', 'zh', 'banner', '{"title":"欢迎使用香港银行","subtitle":"安全可靠的银行服务"}', null),
('ID', 'en', 'banner', '{"title":"Welcome to Indonesia Banking","subtitle":"Secure and reliable banking services"}', null),
('CN', 'en', 'banner', '{"title":"Welcome to China Banking","subtitle":"Secure and reliable banking services"}', null),
('CN', 'zh', 'banner', '{"title":"欢迎使用中国银行","subtitle":"安全可靠的银行服务"}', null),
('VN', 'en', 'banner', '{"title":"Welcome to Vietnam Banking","subtitle":"Secure and reliable banking services"}', null),
('TH', 'en', 'banner', '{"title":"Welcome to Thailand Banking","subtitle":"Secure and reliable banking services"}', null);

-- Insert background images
INSERT INTO content_data (country, language, content_type, content_data, background_url) VALUES
('SG', 'en', 'background', null, '/lovable-uploads/6fffa759-a2a4-48dc-9970-6f351d662bb6.png'),
('SG', 'zh', 'background', null, '/lovable-uploads/6fffa759-a2a4-48dc-9970-6f351d662bb6.png'),
('MY', 'en', 'background', null, '/lovable-uploads/6fffa759-a2a4-48dc-9970-6f351d662bb6.png'),
('MY', 'zh', 'background', null, '/lovable-uploads/6fffa759-a2a4-48dc-9970-6f351d662bb6.png'),
('HK', 'en', 'background', null, '/lovable-uploads/6fffa759-a2a4-48dc-9970-6f351d662bb6.png'),
('HK', 'zh', 'background', null, '/lovable-uploads/6fffa759-a2a4-48dc-9970-6f351d662bb6.png'),
('ID', 'en', 'background', null, '/lovable-uploads/6fffa759-a2a4-48dc-9970-6f351d662bb6.png'),
('CN', 'en', 'background', null, '/lovable-uploads/6fffa759-a2a4-48dc-9970-6f351d662bb6.png'),
('CN', 'zh', 'background', null, '/lovable-uploads/6fffa759-a2a4-48dc-9970-6f351d662bb6.png'),
('VN', 'en', 'background', null, '/lovable-uploads/6fffa759-a2a4-48dc-9970-6f351d662bb6.png'),
('TH', 'en', 'background', null, '/lovable-uploads/6fffa759-a2a4-48dc-9970-6f351d662bb6.png');

-- Insert announcements
INSERT INTO content_data (country, language, content_type, content_data, background_url) VALUES
('SG', 'en', 'announcement', 'Security advisory: Stay vigilant against fraudulent activities in Singapore. Verify all transactions and contact us immediately if you notice any suspicious activity.', null),
('SG', 'zh', 'announcement', '安全提醒：在新加坡保持警惕，防范欺诈活动。验证所有交易，如发现任何可疑活动请立即联系我们。', null),
('MY', 'en', 'announcement', 'Security advisory: Stay vigilant against fraudulent activities in Malaysia. Verify all transactions and contact us immediately if you notice any suspicious activity.', null),
('MY', 'zh', 'announcement', '安全提醒：在马来西亚保持警惕，防范欺诈活动。验证所有交易，如发现任何可疑活动请立即联系我们。', null),
('HK', 'en', 'announcement', 'Security advisory: Stay vigilant against fraudulent activities in Hong Kong. Verify all transactions and contact us immediately if you notice any suspicious activity.', null),
('HK', 'zh', 'announcement', '安全提醒：在香港保持警惕，防范欺诈活动。验证所有交易，如发现任何可疑活动请立即联系我们。', null),
('ID', 'en', 'announcement', 'Security advisory: Stay vigilant against fraudulent activities in Indonesia. Verify all transactions and contact us immediately if you notice any suspicious activity.', null),
('CN', 'en', 'announcement', 'Security advisory: Stay vigilant against fraudulent activities in China. Verify all transactions and contact us immediately if you notice any suspicious activity.', null),
('CN', 'zh', 'announcement', '安全提醒：在中国保持警惕，防范欺诈活动。验证所有交易，如发现任何可疑活动请立即联系我们。', null),
('VN', 'en', 'announcement', 'Security advisory: Stay vigilant against fraudulent activities in Vietnam. Verify all transactions and contact us immediately if you notice any suspicious activity.', null),
('TH', 'en', 'announcement', 'Security advisory: Stay vigilant against fraudulent activities in Thailand. Verify all transactions and contact us immediately if you notice any suspicious activity.', null);
