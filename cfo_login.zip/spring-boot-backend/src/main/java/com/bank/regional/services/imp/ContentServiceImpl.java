
package com.bank.regional.services.imp;

import com.bank.regional.entity.ContentData;
import com.bank.regional.model.ContentResponse;
import com.bank.regional.repository.ContentDataRepository;
import com.bank.regional.services.ContentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class ContentServiceImpl implements ContentService {
    
    @Autowired
    private ContentDataRepository contentDataRepository;
    
    @Override
    public ContentResponse getBanner(String country, String language) {
        Optional<ContentData> content = contentDataRepository.findByCountryAndLanguageAndContentType(
                country.toUpperCase(), language.toLowerCase(), "banner"
        );
        
        if (content.isPresent()) {
            ContentData data = content.get();
            return new ContentResponse(
                    language.equals("zh") ? "欢迎使用企业银行" : "Welcome to Business Banking",
                    language.equals("zh") ? "安全可靠的银行服务" : "Secure and reliable banking services",
                    null,
                    data.getContentData()
            );
        }
        
        return new ContentResponse(
                language.equals("zh") ? "欢迎使用企业银行" : "Welcome to Business Banking",
                language.equals("zh") ? "安全可靠的银行服务" : "Secure and reliable banking services",
                null,
                null
        );
    }
    
    @Override
    public ContentResponse getBackgroundImage(String country, String language) {
        Optional<ContentData> content = contentDataRepository.findByCountryAndLanguageAndContentType(
                country.toUpperCase(), language.toLowerCase(), "background"
        );
        
        if (content.isPresent()) {
            ContentData data = content.get();
            return new ContentResponse(null, null, data.getBackgroundUrl(), data.getContentData());
        }
        
        return new ContentResponse(null, null, "/default-background.jpg", null);
    }
    
    @Override
    public String getAnnouncement(String country, String language) {
        Optional<ContentData> content = contentDataRepository.findByCountryAndLanguageAndContentType(
                country.toUpperCase(), language.toLowerCase(), "announcement"
        );
        
        if (content.isPresent()) {
            return content.get().getContentData();
        }
        
        return language.equals("zh") ? 
                "安全提醒：保持警惕，防范欺诈活动。验证所有交易，如发现任何可疑活动请立即联系我们。" :
                "Security notice: Stay vigilant against fraudulent activities. Verify all transactions and contact us immediately if you notice any suspicious activity.";
    }
}
