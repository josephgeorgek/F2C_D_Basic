
import { execSync } from 'child_process';

try {
  console.log('Running tests...');
  execSync('npx jest', { stdio: 'inherit' });
} catch (error) {
  console.error('Tests failed:', error.message);
  process.exit(1);
}
