
import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import '@testing-library/jest-dom';
import Index from '../pages/Index';

// Mock the services
jest.mock('../services/ContentService', () => ({
  getAnnouncement: jest.fn().mockResolvedValue('Test announcement'),
  getBanner: jest.fn().mockResolvedValue({ title: 'Test banner' })
}));

// Mock the components that might not be available
jest.mock('../components/BankLogo', () => {
  return function BankLogo() {
    return <div data-testid="bank-logo">Bank Logo</div>;
  };
});

jest.mock('../components/CountrySelector', () => {
  return function CountrySelector({ value, onChange }: any) {
    return (
      <select data-testid="country-selector" value={value} onChange={(e) => onChange(e.target.value)}>
        <option value="SG">Singapore</option>
        <option value="MY">Malaysia</option>
      </select>
    );
  };
});

jest.mock('../components/LanguageToggle', () => {
  return function LanguageToggle({ value, onChange }: any) {
    return (
      <div data-testid="language-toggle">
        <button onClick={() => onChange('en')}>English</button>
        <button onClick={() => onChange('zh')}>中文</button>
      </div>
    );
  };
});

jest.mock('../components/NeedHelpDialog', () => {
  return function NeedHelpDialog({ open, onClose }: any) {
    return open ? (
      <div data-testid="need-help-dialog">
        <h2>Fraud related support</h2>
        <button onClick={onClose}>Close</button>
      </div>
    ) : null;
  };
});

jest.mock('../components/NewUserWizard', () => {
  return function NewUserWizard({ open, onClose }: any) {
    return open ? (
      <div data-testid="new-user-wizard">
        <h2>New User Activation</h2>
        <button onClick={onClose}>Close</button>
      </div>
    ) : null;
  };
});

jest.mock('../components/ResetPasswordWizard', () => {
  return function ResetPasswordWizard({ open, onClose }: any) {
    return open ? (
      <div data-testid="reset-password-wizard">
        <h2>Reset Password</h2>
        <button onClick={onClose}>Close</button>
      </div>
    ) : null;
  };
});

describe('Index Page', () => {
  test('renders welcome title', async () => {
    render(<Index />);
    await waitFor(() => {
      expect(screen.getByText('Welcome to Business Banking')).toBeInTheDocument();
    });
  });

  test('renders login form fields', async () => {
    render(<Index />);
    await waitFor(() => {
      expect(screen.getByLabelText(/organisation id/i)).toBeInTheDocument();
      expect(screen.getByLabelText(/user id/i)).toBeInTheDocument();
      expect(screen.getByLabelText(/password/i)).toBeInTheDocument();
    });
  });

  test('opens need help dialog when clicked', async () => {
    const user = userEvent.setup();
    render(<Index />);
    
    await waitFor(() => {
      const helpButton = screen.getByText(/need help/i);
      expect(helpButton).toBeInTheDocument();
    });
    
    await user.click(screen.getByText(/need help/i));
    await waitFor(() => {
      expect(screen.getByText('Fraud related support')).toBeInTheDocument();
    });
  });

  test('toggles password visibility', async () => {
    const user = userEvent.setup();
    render(<Index />);
    
    await waitFor(() => {
      const passwordField = screen.getByLabelText(/password/i) as HTMLInputElement;
      expect(passwordField.type).toBe('password');
    });
    
    const toggleButton = screen.getByRole('button', { name: /toggle password visibility/i });
    await user.click(toggleButton);
    
    const passwordField = screen.getByLabelText(/password/i) as HTMLInputElement;
    expect(passwordField.type).toBe('text');
  });

  test('switches language', async () => {
    const user = userEvent.setup();
    render(<Index />);
    
    await waitFor(() => {
      const chineseButton = screen.getByText('中文');
      expect(chineseButton).toBeInTheDocument();
    });
    
    await user.click(screen.getByText('中文'));
    await waitFor(() => {
      expect(screen.getByText('欢迎使用企业银行')).toBeInTheDocument();
    });
  });
});
