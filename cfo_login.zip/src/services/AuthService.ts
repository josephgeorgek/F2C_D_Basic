
import axios from 'axios';
import ContentService from './ContentService';

interface LoginCredentials {
  organizationId: string;
  userId: string;
  password: string;
  country: string;
}

class AuthService {
  async login(credentials: LoginCredentials): Promise<any> {
    try {
      const loginEndpoint = ContentService.getLoginEndpoint(credentials.country);
      const response = await axios.post(
        loginEndpoint,
        {
          organisationId: credentials.organizationId,
          userId: credentials.userId,
          password: credentials.password
        },
        {
          headers: {
            'Content-Type': 'application/json'
          }
        }
      );
      return response.data;
    } catch (error) {
      console.error('Login failed:', error);
      throw error;
    }
  }

  async resetPassword(organizationId: string, userId: string, country: string): Promise<any> {
    try {
      const response = await axios.post(
        `http://localhost:8080/${country.toLowerCase()}/password-reset`,
        { organizationId, userId }
      );
      return response.data;
    } catch (error) {
      console.error('Password reset failed:', error);
      throw error;
    }
  }

  async activateUser(organizationId: string, userId: string, country: string): Promise<any> {
    try {
      const response = await axios.post(
        `http://localhost:8080/${country.toLowerCase()}/user-activation`,
        { organizationId, userId }
      );
      return response.data;
    } catch (error) {
      console.error('User activation failed:', error);
      throw error;
    }
  }
}

export default new AuthService();
