
import axios from 'axios';

interface LoginCredentials {
  organizationId: string;
  userId: string;
  password: string;
  country: string;
}

class AuthService {
  private baseUrl = 'https://bank-uat.digitalcore.bank.com/digital/api';

  async login(credentials: LoginCredentials): Promise<any> {
    try {
      const response = await axios.post(
        `${this.baseUrl}/${credentials.country.toLowerCase()}/customer-security-corp/v1/orguserid-login`,
        {
          organisationId: credentials.organizationId,
          userId: credentials.userId,
          password: credentials.password
        },
        {
          headers: {
            'Content-Type': 'application/json'
          }
        }
      );
      return response.data;
    } catch (error) {
      console.error('Login failed:', error);
      throw error;
    }
  }

  async resetPassword(organizationId: string, userId: string): Promise<any> {
    try {
      const response = await axios.post(
        `${this.baseUrl}/password-reset`,
        { organizationId, userId }
      );
      return response.data;
    } catch (error) {
      console.error('Password reset failed:', error);
      throw error;
    }
  }

  async activateUser(organizationId: string, userId: string): Promise<any> {
    try {
      const response = await axios.post(
        `${this.baseUrl}/user-activation`,
        { organizationId, userId }
      );
      return response.data;
    } catch (error) {
      console.error('User activation failed:', error);
      throw error;
    }
  }
}

export default new AuthService();
