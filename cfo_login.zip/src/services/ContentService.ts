
import axios from 'axios';

class ContentService {
  private baseUrl = 'https://bank-uat.digitalcore.bank.com/digital-content';
  private interwovenApiUrl = 'https://api.interwoven.com/content'; // Interwoven API endpoint
  
  async getAnnouncement(country: string, language: string): Promise<string> {
    try {
      // First try the interwoven API
      const response = await axios.get(
        `${this.interwovenApiUrl}/announcement`,
        { 
          params: {
            country: country.toLowerCase(),
            language: language,
            type: 'security-advisory'
          },
          headers: {
            'Content-Type': 'application/json',
            'Accept': 'application/json'
          },
          timeout: 5000
        }
      );
      
      if (response.data && response.data.message) {
        console.log('Using interwoven API announcement');
        return response.data.message;
      }
    } catch (error) {
      console.warn('Failed to fetch announcement from interwoven API, trying fallback server');
    }

    try {
      // Fallback to original server
      const response = await axios.get(
        `${this.baseUrl}/${country.toLowerCase()}/business/web/${language}/bfo/prelogin/announcement/microsites/microsite_announcement_${language}_${country}.html`,
        { 
          headers: {
            'Sec-Fetch-Site': 'same-origin',
            'Priority': 'u=4'
          },
          timeout: 5000
        }
      );
      console.log('Using server announcement');
      return response.data;
    } catch (error) {
      console.warn('Failed to fetch announcement from server, using local fallback');
      return this.getFallbackAnnouncement(language);
    }
  }

  async getBanner(country: string, language: string): Promise<any> {
    try {
      const response = await axios.get(
        `${this.baseUrl}/${country.toLowerCase()}/business/web/${language}/bfo/common/banner/banner_content_${language}_${country}.json`,
        { timeout: 5000 }
      );
      return response.data;
    } catch (error) {
      console.warn('Failed to fetch banner from server, using fallback');
      return this.getFallbackBanner(language);
    }
  }

  async getBackgroundImage(country: string, language: string): Promise<string> {
    try {
      const response = await axios.get(
        `${this.baseUrl}/${country.toLowerCase()}/business/web/${language}/bfo/common/images/background_${language}_${country}.json`,
        { timeout: 5000 }
      );
      return response.data.backgroundUrl || this.getFallbackBackgroundImage();
    } catch (error) {
      console.warn('Failed to fetch background image from server, using fallback');
      return this.getFallbackBackgroundImage();
    }
  }

  private getFallbackAnnouncement(language: string): string {
    console.log('Using local fallback announcement');
    const fallbacks = {
      en: 'Security notice: Stay vigilant against fraudulent activities. Verify all transactions and contact us immediately if you notice any suspicious activity.',
      zh: '安全提醒：保持警惕，防范欺诈活动。验证所有交易，如发现任何可疑活动请立即联系我们。'
    };
    return fallbacks[language] || fallbacks.en;
  }

  private getFallbackBanner(language: string): any {
    return {
      title: language === 'zh' ? '欢迎使用企业银行' : 'Welcome to Business Banking',
      subtitle: language === 'zh' ? '安全可靠的银行服务' : 'Secure and reliable banking services'
    };
  }

  private getFallbackBackgroundImage(): string {
    return '/lovable-uploads/6fffa759-a2a4-48dc-9970-6f351d662bb6.png';
  }
}

export default new ContentService();
