
import React from 'react';
import { ToggleButton, ToggleButtonGroup } from '@mui/material';

interface LanguageToggleProps {
  value: string;
  onChange: (value: string) => void;
}

const LanguageToggle: React.FC<LanguageToggleProps> = ({ value, onChange }) => {
  return (
    <ToggleButtonGroup
      value={value}
      exclusive
      onChange={(_, newValue) => newValue && onChange(newValue)}
      size="small"
    >
      <ToggleButton value="en">English</ToggleButton>
      <ToggleButton value="zh">中文</ToggleButton>
    </ToggleButtonGroup>
  );
};

export default LanguageToggle;
