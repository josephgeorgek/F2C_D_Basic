
import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { X, AlertTriangle, Shield, Battery, HelpCircle, Smartphone, Key } from 'lucide-react';
import { Separator } from '@/components/ui/separator';

interface NeedHelpDialogProps {
  open: boolean;
  onClose: () => void;
  language: string;
}

const NeedHelpDialog: React.FC<NeedHelpDialogProps> = ({ open, onClose, language }) => {
  const texts = {
    en: {
      title: 'Need help?',
      fraudSupport: 'Fraud related support',
      reportFraud: 'Report fraud',
      blockAccess: 'Block access to account(s)',
      faqs: 'Frequently asked questions (FAQs)',
      batteryIssue: 'My hardware token has run out of battery. What should I do?',
      forgotCredentials: 'I have forgotten my Organisation and/ or User ID. Where can I find them?',
      newDevice: 'I have a new mobile device. How can I reactivate digital token?',
      activationIssues: 'I am experiencing issues activating soft token. What should I do?',
      viewAllFaqs: 'View all FAQs',
      close: 'Close'
    },
    zh: {
      title: '需要帮助？',
      fraudSupport: '欺诈相关支持',
      reportFraud: '举报欺诈',
      blockAccess: '阻止账户访问',
      faqs: '常见问题 (FAQs)',
      batteryIssue: '我的硬件令牌电池已耗尽。我该怎么办？',
      forgotCredentials: '我忘记了机构和/或用户ID。在哪里可以找到它们？',
      newDevice: '我有一个新的移动设备。如何重新激活数字令牌？',
      activationIssues: '我在激活软令牌时遇到问题。我该怎么办？',
      viewAllFaqs: '查看所有常见问题',
      close: '关闭'
    }
  };

  const currentTexts = texts[language] || texts.en;

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-md p-0 gap-0 font-sans">
        {/* Header with red bank logo pattern */}
        <DialogHeader className="bg-white border-b border-gray-200 p-4 rounded-t-lg relative">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <span className="text-red-600 font-bold text-lg">Redbank</span>
              <span className="text-gray-900 font-normal text-lg">{currentTexts.title}</span>
            </div>
            <Button 
              onClick={onClose}
              variant="ghost"
              size="sm"
              className="text-gray-500 hover:bg-gray-100 h-6 w-6 p-0"
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
        </DialogHeader>

        <div className="p-0">
          {/* Fraud Support Section */}
          <div className="p-4 bg-red-50">
            <h3 className="text-sm font-semibold text-red-800 mb-3">
              {currentTexts.fraudSupport}
            </h3>
            <div className="space-y-2">
              <button className="flex items-center gap-3 w-full text-left p-2 hover:bg-red-100 rounded text-sm">
                <AlertTriangle className="h-4 w-4 text-red-600" />
                <span className="text-red-800">{currentTexts.reportFraud}</span>
              </button>
              <button className="flex items-center gap-3 w-full text-left p-2 hover:bg-red-100 rounded text-sm">
                <Shield className="h-4 w-4 text-red-600" />
                <span className="text-red-800">{currentTexts.blockAccess}</span>
              </button>
            </div>
          </div>

          <Separator />

          {/* FAQs Section */}
          <div className="p-4">
            <h3 className="text-sm font-semibold text-gray-900 mb-3">
              {currentTexts.faqs}
            </h3>
            
            <div className="space-y-1">
              <button className="flex items-start gap-3 w-full text-left p-2 hover:bg-gray-50 rounded">
                <Battery className="h-4 w-4 text-gray-500 mt-0.5" />
                <span className="text-xs text-gray-700 leading-relaxed">
                  {currentTexts.batteryIssue}
                </span>
              </button>
              
              <button className="flex items-start gap-3 w-full text-left p-2 hover:bg-gray-50 rounded">
                <HelpCircle className="h-4 w-4 text-gray-500 mt-0.5" />
                <span className="text-xs text-gray-700 leading-relaxed">
                  {currentTexts.forgotCredentials}
                </span>
              </button>
              
              <button className="flex items-start gap-3 w-full text-left p-2 hover:bg-gray-50 rounded">
                <Smartphone className="h-4 w-4 text-gray-500 mt-0.5" />
                <span className="text-xs text-gray-700 leading-relaxed">
                  {currentTexts.newDevice}
                </span>
              </button>
              
              <button className="flex items-start gap-3 w-full text-left p-2 hover:bg-gray-50 rounded">
                <Key className="h-4 w-4 text-gray-500 mt-0.5" />
                <span className="text-xs text-gray-700 leading-relaxed">
                  {currentTexts.activationIssues}
                </span>
              </button>
            </div>

            <div className="mt-4 text-center">
              <button className="text-blue-600 hover:text-blue-800 text-sm">
                {currentTexts.viewAllFaqs}
              </button>
            </div>
          </div>

          <Separator />

          {/* Footer */}
          <div className="p-4 bg-gray-50">
            <Button onClick={onClose} className="w-full bg-gray-600 hover:bg-gray-700 text-white">
              {currentTexts.close}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default NeedHelpDialog;
