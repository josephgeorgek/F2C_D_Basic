
import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Checkbox } from '@/components/ui/checkbox';
import { X, Check } from 'lucide-react';
import BankLogo from './BankLogo';

interface NewUserWizardProps {
  open: boolean;
  onClose: () => void;
  language: string;
}

const NewUserWizard: React.FC<NewUserWizardProps> = ({ open, onClose, language }) => {
  const [activeStep, setActiveStep] = useState(0);
  const [organizationId, setOrganizationId] = useState('');
  const [userId, setUserId] = useState('');

  const texts = {
    en: {
      title: 'ACTIVATE ACCESS',
      subtitle: 'Enter your login credentials',
      description: 'When you open your account, we will send a unique Organisation ID and User ID to your email address in our records. Please check your inbox.',
      organizationId: 'Organisation ID',
      userId: 'User ID',
      back: 'Back',
      next: 'Next',
      steps: ['Enter login credentials', 'Verify number', 'Password reset', 'Activate hardware token']
    },
    zh: {
      title: '激活访问',
      subtitle: '输入您的登录凭据',
      description: '当您开设账户时，我们会将唯一的机构ID和用户ID发送到我们记录中的电子邮件地址。请检查您的收件箱。',
      organizationId: '机构编号',
      userId: '用户编号',
      back: '返回',
      next: '下一步',
      steps: ['输入登录凭据', '验证号码', '密码重置', '激活硬件令牌']
    }
  };

  const currentTexts = texts[language] || texts.en;

  const handleNext = () => {
    if (activeStep < 3) {
      setActiveStep(activeStep + 1);
    }
  };

  const handleBack = () => {
    if (activeStep > 0) {
      setActiveStep(activeStep - 1);
    }
  };

  const renderStepContent = () => {
    switch (activeStep) {
      case 0:
        return (
          <div className="flex-1 p-8">
            <h2 className="text-xl font-semibold mb-2">{currentTexts.subtitle}</h2>
            <p className="text-gray-600 mb-6">{currentTexts.description}</p>
            
            <div className="space-y-4 mb-6">
              <div>
                <Label htmlFor="org-id" className="block text-sm font-medium mb-2">
                  {currentTexts.organizationId}
                </Label>
                <Input
                  id="org-id"
                  value={organizationId}
                  onChange={(e) => setOrganizationId(e.target.value)}
                  placeholder="ACME001"
                  className="w-full"
                />
              </div>
              <div>
                <Label htmlFor="user-id" className="block text-sm font-medium mb-2">
                  {currentTexts.userId}
                </Label>
                <Input
                  id="user-id"
                  value={userId}
                  onChange={(e) => setUserId(e.target.value)}
                  placeholder="JOHNDOE"
                  className="w-full"
                />
              </div>
            </div>
            
            <Alert className="border-orange-200 bg-orange-50">
              <AlertDescription className="text-orange-800">
                One or more login credentials are invalid
              </AlertDescription>
            </Alert>
          </div>
        );
      case 1:
        return (
          <div className="flex-1 p-8">
            <h2 className="text-xl font-semibold mb-2">Verify Your Number</h2>
            <p className="text-gray-600 mb-6">We'll send a verification code to your registered mobile number.</p>
          </div>
        );
      case 2:
        return (
          <div className="flex-1 p-8">
            <h2 className="text-xl font-semibold mb-2">Set New Password</h2>
            <p className="text-gray-600 mb-6">Create a secure password for your account.</p>
          </div>
        );
      case 3:
        return (
          <div className="flex-1 p-8">
            <h2 className="text-xl font-semibold mb-2">Activate Hardware Token</h2>
            <p className="text-gray-600 mb-6">Follow the instructions to activate your hardware token.</p>
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl h-[80vh] p-0 gap-0 font-sans [&>button]:hidden">
        {/* Header with red left edge and bank logo */}
        <DialogHeader className="bg-white border-l-4 border-l-red-600 p-6 flex flex-row items-center justify-between">
          <div className="flex items-center gap-4">
            <BankLogo />
            <DialogTitle className="text-lg font-semibold">{currentTexts.title}</DialogTitle>
          </div>
          <Button 
            onClick={onClose}
            variant="ghost"
            size="sm"
            className="text-gray-600 hover:bg-gray-100"
          >
            <X className="h-4 w-4" />
          </Button>
        </DialogHeader>

        <div className="flex flex-1">
          {/* Left Sidebar - Vertical Step Navigator with connecting lines */}
          <div className="w-80 bg-gray-50 border-r border-gray-200 p-6">
            <div className="space-y-0 relative">
              {currentTexts.steps.map((step, index) => (
                <div key={index} className="relative">
                  <div className="flex items-center space-x-3 py-4">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium relative z-10 ${
                      index < activeStep 
                        ? 'bg-green-600 text-white' 
                        : index === activeStep 
                        ? 'bg-red-600 text-white' 
                        : 'bg-gray-200 text-gray-600'
                    }`}>
                      {index < activeStep ? <Check className="h-4 w-4" /> : index + 1}
                    </div>
                    <span className={`text-sm ${
                      index <= activeStep ? 'text-gray-900 font-medium' : 'text-gray-500'
                    }`}>
                      {step}
                    </span>
                  </div>
                  
                  {/* Connecting line - Fixed gap */}
                  {index < currentTexts.steps.length - 1 && (
                    <div className="absolute left-4 top-12 w-0.5 h-8 bg-gray-300"></div>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Right Content Area */}
          <div className="flex-1 flex flex-col">
            {renderStepContent()}
            
            {/* Footer Actions */}
            <div className="border-t border-gray-200 p-6 flex justify-between bg-gray-50">
              <Button 
                onClick={handleBack}
                disabled={activeStep === 0}
                variant="outline"
                className="px-6"
              >
                {currentTexts.back}
              </Button>
              <Button 
                onClick={handleNext}
                disabled={activeStep === 0 && (!organizationId || !userId)}
                className="bg-red-600 hover:bg-red-700 px-6"
              >
                {currentTexts.next}
              </Button>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default NewUserWizard;
