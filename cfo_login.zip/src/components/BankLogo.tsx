
import React from 'react';

const BankLogo = () => {
  return (
    <div className="flex items-center gap-2">
      <img 
        src="/lovable-uploads/50fa8cab-c0a5-4561-a9d4-96ffe18280be.png" 
        alt="Redbank Logo" 
        className="h-6"
      />
    </div>
  );
};

export default BankLogo;
