
import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { X, Check } from 'lucide-react';
import BankLogo from './BankLogo';

interface ResetPasswordWizardProps {
  open: boolean;
  onClose: () => void;
  language: string;
}

const ResetPasswordWizard: React.FC<ResetPasswordWizardProps> = ({ open, onClose, language }) => {
  const [activeStep, setActiveStep] = useState(0);
  const [organizationId, setOrganizationId] = useState('');
  const [userId, setUserId] = useState('');
  const [agreeTerms, setAgreeTerms] = useState(false);

  const texts = {
    en: {
      title: 'RESET PASSWORD OR UNLOCK ACCOUNT',
      subtitle: 'Enter your login credentials',
      description: 'We need your User ID and Organisation ID when your account was opened. Please check your registered email for these login credentials.',
      organizationId: 'Organisation ID',
      userId: 'User ID',
      agreeTerms: 'By clicking "Next", you confirm that you have read and understood, and agree to be bound by our Terms and Conditions.',
      back: 'Back',
      next: 'Next',
      steps: ['Login credentials', '2-step verification', 'Password reset']
    },
    zh: {
      title: '重置密码或解锁账户',
      subtitle: '输入您的登录凭据',
      description: '当您开设账户时，我们需要您的用户ID和机构ID。请检查您注册的电子邮件以获取这些登录凭据。',
      organizationId: '机构编号',
      userId: '用户编号',
      agreeTerms: '点击"下一步"，即表示您确认已阅读并理解，并同意受我们的条款和条件约束。',
      back: '返回',
      next: '下一步',
      steps: ['登录凭据', '两步验证', '密码重置']
    }
  };

  const currentTexts = texts[language] || texts.en;

  const handleNext = () => {
    if (activeStep < 2) {
      setActiveStep(activeStep + 1);
    }
  };

  const handleBack = () => {
    if (activeStep > 0) {
      setActiveStep(activeStep - 1);
    }
  };

  const renderStepContent = () => {
    switch (activeStep) {
      case 0:
        return (
          <div className="flex-1 p-8">
            <h2 className="text-xl font-semibold mb-2">{currentTexts.subtitle}</h2>
            <p className="text-gray-600 mb-6">{currentTexts.description}</p>
            
            <div className="space-y-4 mb-6">
              <div>
                <Label htmlFor="org-id" className="block text-sm font-medium mb-2">
                  {currentTexts.organizationId}
                </Label>
                <Input
                  id="org-id"
                  value={organizationId}
                  onChange={(e) => setOrganizationId(e.target.value)}
                  placeholder="ACME001"
                  className="w-full"
                />
              </div>
              <div>
                <Label htmlFor="user-id" className="block text-sm font-medium mb-2">
                  {currentTexts.userId}
                </Label>
                <Input
                  id="user-id"
                  value={userId}
                  onChange={(e) => setUserId(e.target.value)}
                  placeholder="JOHNDOE"
                  className="w-full"
                />
              </div>
            </div>
            
            <div className="flex items-start space-x-2">
              <Checkbox
                id="terms"
                checked={agreeTerms}
                onCheckedChange={(checked) => setAgreeTerms(checked as boolean)}
                className="mt-1"
              />
              <Label htmlFor="terms" className="text-sm text-gray-600 leading-relaxed">
                {currentTexts.agreeTerms}
              </Label>
            </div>
          </div>
        );
      case 1:
        return (
          <div className="flex-1 p-8">
            <h2 className="text-xl font-semibold mb-2">Two-Step Verification</h2>
            <p className="text-gray-600 mb-6">We'll verify your identity using your registered contact information.</p>
          </div>
        );
      case 2:
        return (
          <div className="flex-1 p-8">
            <h2 className="text-xl font-semibold mb-2">Reset Your Password</h2>
            <p className="text-gray-600 mb-6">Create a new secure password for your account.</p>
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl h-[80vh] p-0 gap-0 font-sans">
        {/* Header with red left edge and bank logo */}
        <DialogHeader className="bg-white border-l-4 border-l-red-600 p-6 flex flex-row items-center justify-between">
          <div className="flex items-center gap-4">
            <BankLogo />
            <DialogTitle className="text-lg font-semibold">{currentTexts.title}</DialogTitle>
          </div>
          <Button 
            onClick={onClose}
            variant="ghost"
            size="sm"
            className="text-gray-600 hover:bg-gray-100"
          >
            <X className="h-4 w-4" />
          </Button>
        </DialogHeader>

        <div className="flex flex-1">
          {/* Left Sidebar - Vertical Step Navigator with connecting lines */}
          <div className="w-80 bg-gray-50 border-r border-gray-200 p-6">
            <div className="space-y-0 relative">
              {currentTexts.steps.map((step, index) => (
                <div key={index} className="relative">
                  <div className="flex items-center space-x-3 py-4">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium relative z-10 ${
                      index < activeStep 
                        ? 'bg-green-600 text-white' 
                        : index === activeStep 
                        ? 'bg-red-600 text-white' 
                        : 'bg-gray-200 text-gray-600'
                    }`}>
                      {index < activeStep ? <Check className="h-4 w-4" /> : index + 1}
                    </div>
                    <span className={`text-sm ${
                      index <= activeStep ? 'text-gray-900 font-medium' : 'text-gray-500'
                    }`}>
                      {step}
                    </span>
                  </div>
                  
                  {/* Connecting line */}
                  {index < currentTexts.steps.length - 1 && (
                    <div className="absolute left-4 top-12 w-0.5 h-4 bg-gray-300"></div>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Right Content Area */}
          <div className="flex-1 flex flex-col">
            {renderStepContent()}
            
            {/* Footer Actions */}
            <div className="border-t border-gray-200 p-6 flex justify-between bg-gray-50">
              <Button 
                onClick={handleBack}
                disabled={activeStep === 0}
                variant="outline"
                className="px-6"
              >
                {currentTexts.back}
              </Button>
              <Button 
                onClick={handleNext}
                disabled={activeStep === 0 && (!organizationId || !userId || !agreeTerms)}
                className="bg-red-600 hover:bg-red-700 px-6"
              >
                {currentTexts.next}
              </Button>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default ResetPasswordWizard;
