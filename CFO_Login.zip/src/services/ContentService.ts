
import axios from 'axios';

class ContentService {
  private baseUrl = 'https://bank-uat.digitalcore.bank.com/digital-content';
  
  async getAnnouncement(country: string, language: string): Promise<string> {
    try {
      const response = await axios.get(
        `${this.baseUrl}/${country.toLowerCase()}/business/web/${language}/bfo/prelogin/announcement/microsites/microsite_announcement_${language}_${country}.html`,
        { 
          headers: {
            'Sec-Fetch-Site': 'same-origin',
            'Priority': 'u=4'
          }
        }
      );
      return response.data;
    } catch (error) {
      console.warn('Failed to fetch announcement from server, using fallback');
      return this.getFallbackAnnouncement(language);
    }
  }

  async getBanner(country: string, language: string): Promise<any> {
    try {
      const response = await axios.get(
        `${this.baseUrl}/${country.toLowerCase()}/business/web/${language}/bfo/common/banner/banner_content_${language}_${country}.json`
      );
      return response.data;
    } catch (error) {
      console.warn('Failed to fetch banner from server, using fallback');
      return this.getFallbackBanner(language);
    }
  }

  async getBackgroundImage(country: string, language: string): Promise<string> {
    try {
      const response = await axios.get(
        `${this.baseUrl}/${country.toLowerCase()}/business/web/${language}/bfo/common/images/background_${language}_${country}.json`
      );
      return response.data.backgroundUrl || this.getFallbackBackgroundImage();
    } catch (error) {
      console.warn('Failed to fetch background image from server, using fallback');
      return this.getFallbackBackgroundImage();
    }
  }

  private getFallbackAnnouncement(language: string): string {
    const fallbacks = {
      en: 'Security advisory: Received a bulk order or service request from an organisation? Please independently verify the identity of the party you are corresponding with. Avoid making payment or deposits in advance to new suppliers.',
      zh: '安全提醒：收到来自某机构的批量订单或服务请求？请独立验证您所对应方的身份。避免向新供应商提前付款或存款。'
    };
    return fallbacks[language] || fallbacks.en;
  }

  private getFallbackBanner(language: string): any {
    return {
      title: language === 'zh' ? '欢迎使用企业银行' : 'Welcome to Business Banking',
      subtitle: language === 'zh' ? '安全可靠的银行服务' : 'Secure and reliable banking services'
    };
  }

  private getFallbackBackgroundImage(): string {
    return '/lovable-uploads/6fffa759-a2a4-48dc-9970-6f351d662bb6.png';
  }
}

export default new ContentService();
