package com.example.pgp;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;

public class App {
    public static void main(String[] args) throws Exception {
        if (args.length == 0) {
            printHelp();
            return;
        }
        var cmd = args[0];
        var params = parseArgs(args);

        switch (cmd) {
            case "encrypt-sign" -> runEncryptSign(params);
            case "decrypt-verify" -> runDecryptVerify(params);
            case "help" -> printHelp();
            default -> {
                System.err.println("Unknown command: " + cmd);
                printHelp();
            }
        }
    }

    private static void runEncryptSign(Map<String, String> p) throws Exception {
        required(p, "--in", "--out", "--enc-pub", "--sign-sec", "--sign-pass");

        var in = Path.of(p.get("--in"));
        var out = Path.of(p.get("--out"));
        var encPub = Path.of(p.get("--enc-pub"));
        var signSec = Path.of(p.get("--sign-sec"));
        var signPass = p.get("--sign-pass").toCharArray();
        var armor = p.containsKey("--armor");

        Crypto.encryptAndSign(
                Files.readAllBytes(in),
                Files.readString(in.getFileName()), // name hint for literal data
                encPub,
                signSec,
                signPass,
                out,
                armor
        );
        System.out.println("Written: " + out.toAbsolutePath());
    }

    private static void runDecryptVerify(Map<String, String> p) throws Exception {
        required(p, "--in", "--out", "--dec-sec", "--dec-pass", "--verify-pub");

        var in = Path.of(p.get("--in"));
        var out = Path.of(p.get("--out"));
        var decSec = Path.of(p.get("--dec-sec"));
        var decPass = p.get("--dec-pass").toCharArray();
        var verifyPub = Path.of(p.get("--verify-pub"));

        var result = Crypto.decryptAndVerify(
                Files.readAllBytes(in),
                decSec,
                decPass,
                verifyPub
        );
        Files.write(out, result.plaintext());
        System.out.println("Verification OK? " + result.signatureVerified());
        System.out.println("Written: " + out.toAbsolutePath());
    }

    private static void printHelp() {
        System.out.println("""
pgp-gpg-demo-java

Usage:
  encrypt-sign --in <file> --out <file.pgp> --enc-pub <recipient_pub.asc> --sign-sec <sender_sec.asc> --sign-pass <pass> [--armor]
  decrypt-verify --in <file.pgp> --out <file> --dec-sec <recipient_sec.asc> --dec-pass <pass> --verify-pub <sender_pub.asc>

""");
    }

    private static void required(Map<String, String> params, String... keys) {
        for (var k : keys) {
            if (!params.containsKey(k)) {
                throw new IllegalArgumentException("Missing required arg: " + k);
            }
        }
    }

    private static Map<String, String> parseArgs(String[] args) {
        Map<String, String> m = new HashMap<>();
        for (int i = 1; i < args.length; i++) {
            String a = args[i];
            if (a.startsWith("--")) {
                if (i + 1 < args.length && !args[i + 1].startsWith("--")) {
                    m.put(a, args[++i]);
                } else {
                    m.put(a, "true");
                }
            }
        }
        return m;
    }
}
