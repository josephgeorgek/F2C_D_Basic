package com.example.pgp;

import org.bouncycastle.bcpg.ArmoredOutputStream;
import org.bouncycastle.bcpg.HashAlgorithmTags;
import org.bouncycastle.bcpg.SymmetricKeyAlgorithmTags;
import org.bouncycastle.bcpg.sig.Features;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.openpgp.*;
import org.bouncycastle.openpgp.operator.PBESecretKeyDecryptor;
import org.bouncycastle.openpgp.operator.PGPDigestCalculator;
import org.bouncycastle.openpgp.operator.bc.*;
import org.bouncycastle.util.io.Streams;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.Security;
import java.util.Date;
import java.util.Iterator;

public class Crypto {

    static {
        // Ensure BC provider is registered
        if (Security.getProvider(BouncyCastleProvider.PROVIDER_NAME) == null) {
            Security.addProvider(new BouncyCastleProvider());
        }
    }

    public record VerifyResult(byte[] plaintext, boolean signatureVerified) {}

    public static void encryptAndSign(byte[] data,
                                      String fileNameHint,
                                      Path recipientPublicKeyFile,
                                      Path senderSecretKeyFile,
                                      char[] senderPass,
                                      Path outFile,
                                      boolean armor) throws Exception {

        PGPPublicKey encKey = PGPHelper.readEncryptionKey(recipientPublicKeyFile);
        PGPSecretKey signingSecretKey = PGPHelper.readSigningSecretKey(senderSecretKeyFile);
        PGPPrivateKey signingPrivateKey = PGPHelper.extractPrivateKey(signingSecretKey, senderPass);

        // Create a signature over literal data
        ByteArrayOutputStream literalOut = new ByteArrayOutputStream();
        ByteArrayOutputStream signedOut = new ByteArrayOutputStream();

        // Compress + literal data
        PGPCompressedDataGenerator comData = new PGPCompressedDataGenerator(PGPCompressedData.ZLIB);
        try (OutputStream cos = comData.open(literalOut)) {
            PGPLiteralDataGenerator lGen = new PGPLiteralDataGenerator();
            try (OutputStream lOut = lGen.open(cos,
                    PGPLiteralData.BINARY,
                    fileNameHint == null ? "data" : fileNameHint,
                    data.length,
                    new Date())) {
                lOut.write(data);
            }
        }
        comData.close();

        // Sign the compressed literal data
        int hashAlgo = HashAlgorithmTags.SHA256;
        PGPSignatureGenerator sGen = new PGPSignatureGenerator(
                new BcPGPContentSignerBuilder(signingSecretKey.getPublicKey().getAlgorithm(), hashAlgo));
        sGen.init(PGPSignature.BINARY_DOCUMENT, signingPrivateKey);

        PGPSignatureSubpacketGenerator spGen = new PGPSignatureSubpacketGenerator();
        spGen.setFeature(true, Features.FEATURE_MODIFICATION_DETECTION);
        sGen.setHashedSubpackets(spGen.generate());

        ByteArrayInputStream dataToSign = new ByteArrayInputStream(literalOut.toByteArray());
        PGPCompressedDataGenerator cGenSig = new PGPCompressedDataGenerator(PGPCompressedData.ZLIB);
        try (BCPGOutputStream bOut = new BCPGOutputStream(cGenSig.open(signedOut))) {
            sGen.generateOnePassVersion(false).encode(bOut);

            // Re-emit literal data inside the signed stream
            // We need to re-create literal packet so that signature covers it
            byte[] literalBytes = literalOut.toByteArray();
            PGPLiteralDataGenerator lGen2 = new PGPLiteralDataGenerator();
            try (OutputStream lOut = lGen2.open(bOut,
                    PGPLiteralData.BINARY,
                    fileNameHint == null ? "data" : fileNameHint,
                    literalBytes.length,
                    new Date())) {
                // Feed the data to signature generator while writing
                InputStream in = new ByteArrayInputStream(data);
                byte[] buf = new byte[8192];
                int r;
                while ((r = in.read(buf)) >= 0) {
                    lOut.write(buf, 0, r);
                    sGen.update(buf, 0, r);
                }
            }
            sGen.generate().encode(bOut);
        }
        cGenSig.close();

        // Encrypt the signed data
        OutputStream fileOut = Files.newOutputStream(outFile);
        if (armor) {
            fileOut = new ArmoredOutputStream(fileOut);
        }
        try (OutputStream finalOut = fileOut) {
            PGPEncryptedDataGenerator encGen = new PGPEncryptedDataGenerator(
                    new BcPGPDataEncryptorBuilder(SymmetricKeyAlgorithmTags.AES_256)
                            .setWithIntegrityPacket(true)
                            .setSecureRandom(new java.security.SecureRandom()));
            encGen.addMethod(new BcPublicKeyKeyEncryptionMethodGenerator(encKey));
            byte[] signedBytes = signedOut.toByteArray();
            try (OutputStream encOut = encGen.open(finalOut, signedBytes.length)) {
                encOut.write(signedBytes);
            }
        }
    }

    public static VerifyResult decryptAndVerify(byte[] encrypted,
                                                Path recipientSecretKeyFile,
                                                char[] recipientPass,
                                                Path senderPublicKeyFile) throws Exception {

        // Decrypt
        InputStream in = new ByteArrayInputStream(encrypted);
        in = PGPUtil.getDecoderStream(in); // handles armored/binary transparently

        JcaPGPObjectFactory pgpF = new JcaPGPObjectFactory(in);
        Object o = pgpF.nextObject();
        PGPEncryptedDataList enc;
        if (o instanceof PGPEncryptedDataList) {
            enc = (PGPEncryptedDataList) o;
        } else {
            enc = (PGPEncryptedDataList) pgpF.nextObject();
        }

        // Find private key for one of the encrypted session keys
        PGPSecretKeyRingCollection secRings = PGPHelper.readSecretKeyRings(recipientSecretKeyFile);
        PGPPrivateKey sKey = null;
        PGPPublicKeyEncryptedData pbe = null;

        Iterator<PGPEncryptedData> it = enc.getEncryptedDataObjects();
        while (it.hasNext()) {
            Object encObj = it.next();
            if (encObj instanceof PGPPublicKeyEncryptedData) {
                PGPPublicKeyEncryptedData pked = (PGPPublicKeyEncryptedData) encObj;
                PGPSecretKey sk = PGPHelper.findSecretKeyByKeyId(secRings, pked.getKeyID());
                if (sk != null) {
                    sKey = PGPHelper.extractPrivateKey(sk, recipientPass);
                    pbe = pked;
                    break;
                }
            }
        }
        if (sKey == null || pbe == null) {
            throw new IllegalStateException("No suitable secret key found to decrypt.");
        }

        InputStream clear = pbe.getDataStream(new BcPublicKeyDataDecryptorFactory(sKey));
        JcaPGPObjectFactory plainFact = new JcaPGPObjectFactory(clear);
        Object message = plainFact.nextObject();

        // Encrypted message should be a compressed, signed content
        if (message instanceof PGPCompressedData) {
            PGPCompressedData cData = (PGPCompressedData) message;
            JcaPGPObjectFactory pgpFact = new JcaPGPObjectFactory(cData.getDataStream());
            PGPOnePassSignatureList onePassSignatureList = (PGPOnePassSignatureList) pgpFact.nextObject();
            PGPOnePassSignature ops = onePassSignatureList.get(0);

            PGPLiteralData literal = (PGPLiteralData) pgpFact.nextObject();
            InputStream literalIn = literal.getInputStream();
            ByteArrayOutputStream out = new ByteArrayOutputStream();

            // Init verification
            PGPPublicKeyRingCollection pubRings = PGPHelper.readPublicKeyRings(senderPublicKeyFile);
            PGPPublicKey sigPubKey = pubRings.getPublicKey(ops.getKeyID());
            ops.init(new BcPGPContentVerifierBuilderProvider(), sigPubKey);

            byte[] buf = new byte[8192];
            int len;
            while ((len = literalIn.read(buf)) >= 0) {
                ops.update(buf, 0, len);
                out.write(buf, 0, len);
            }

            PGPSignatureList sigList = (PGPSignatureList) pgpFact.nextObject();
            boolean verified = ops.verify(sigList.get(0));

            if (pbe.isIntegrityProtected() && !pbe.verify()) {
                throw new PGPException("Modification integrity check failed.");
            }
            return new VerifyResult(out.toByteArray(), verified);
        } else {
            throw new PGPException("Unexpected message type: " + message.getClass());
        }
    }
}
