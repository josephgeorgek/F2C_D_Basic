package com.example.pgp;

import org.bouncycastle.openpgp.*;
import org.bouncycastle.openpgp.operator.PBESecretKeyDecryptor;
import org.bouncycastle.openpgp.operator.PGPDigestCalculator;
import org.bouncycastle.openpgp.operator.bc.*;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Iterator;

public class PGPHelper {

    public static PGPPublicKey readEncryptionKey(Path pubKeyFile) throws IOException, PGPException {
        PGPPublicKeyRingCollection pubRings = readPublicKeyRings(pubKeyFile);
        PGPPublicKey key = null;
        for (Iterator<PGPPublicKeyRing> i = pubRings.getKeyRings(); i.hasNext();) {
            PGPPublicKeyRing kRing = i.next();
            for (Iterator<PGPPublicKey> j = kRing.getPublicKeys(); j.hasNext();) {
                PGPPublicKey k = j.next();
                if (k.isEncryptionKey()) {
                    key = k;
                    break;
                }
            }
            if (key != null) break;
        }
        if (key == null) throw new IllegalArgumentException("No encryption key found in " + pubKeyFile);
        return key;
    }

    public static PGPSecretKey readSigningSecretKey(Path secKeyFile) throws IOException, PGPException {
        PGPSecretKeyRingCollection secRings = readSecretKeyRings(secKeyFile);
        for (Iterator<PGPSecretKeyRing> i = secRings.getKeyRings(); i.hasNext();) {
            PGPSecretKeyRing ring = i.next();
            for (Iterator<PGPSecretKey> j = ring.getSecretKeys(); j.hasNext();) {
                PGPSecretKey sk = j.next();
                if (sk.isSigningKey()) return sk;
            }
        }
        throw new IllegalArgumentException("No signing secret key found in " + secKeyFile);
    }

    public static PGPPrivateKey extractPrivateKey(PGPSecretKey secretKey, char[] pass) throws PGPException {
        PGPDigestCalculator calc = new BcPGPDigestCalculatorProvider().get(secretKey.getKeyEncryptionAlgorithm());
        PBESecretKeyDecryptor decryptor = new BcPBESecretKeyDecryptorBuilder(calc).build(pass);
        return secretKey.extractPrivateKey(decryptor);
    }

    public static PGPSecretKey findSecretKeyByKeyId(PGPSecretKeyRingCollection secRings, long keyId) throws PGPException {
        for (Iterator<PGPSecretKeyRing> i = secRings.getKeyRings(); i.hasNext();) {
            PGPSecretKeyRing ring = i.next();
            PGPSecretKey sk = ring.getSecretKey(keyId);
            if (sk != null) return sk;
        }
        return null;
    }

    public static PGPPublicKeyRingCollection readPublicKeyRings(Path f) throws IOException, PGPException {
        try (InputStream in = PGPUtil.getDecoderStream(Files.newInputStream(f))) {
            return new PGPPublicKeyRingCollection(in, new BcKeyFingerprintCalculator());
        }
    }

    public static PGPSecretKeyRingCollection readSecretKeyRings(Path f) throws IOException, PGPException {
        try (InputStream in = PGPUtil.getDecoderStream(Files.newInputStream(f))) {
            return new PGPSecretKeyRingCollection(in, new BcKeyFingerprintCalculator());
        }
    }
}
