#!/usr/bin/env bash
set -euo pipefail

mkdir -p keys
cd keys

# Clean old exports (safe for demo)
rm -f customer_pub.asc customer_sec.asc bank_pub.asc bank_sec.asc || true

# Create minimal batch templates
cat > customer-batch.txt <<'EOF'
%echo Generating a customer test key
Key-Type: default
Key-Length: 3072
Subkey-Type: default
Subkey-Length: 3072
Name-Real: Customer Demo
Name-Email: customer@example.com
Expire-Date: 0
Passphrase: customer-pass
%no-protection
%commit
%echo done
EOF

cat > bank-batch.txt <<'EOF'
%echo Generating a bank test key
Key-Type: default
Key-Length: 3072
Subkey-Type: default
Subkey-Length: 3072
Name-Real: Bank Demo
Name-Email: bank@example.com
Expire-Date: 0
Passphrase: bank-pass
%no-protection
%commit
%echo done
EOF

# Use a temporary GNUPGHOME so we don't touch the user's default keyring
export GNUPGHOME="$(pwd)/.gnupg-demo"
rm -rf "$GNUPGHOME"
mkdir -p "$GNUPGHOME"
chmod 700 "$GNUPGHOME"

# Generate keys
gpg --batch --generate-key customer-batch.txt
gpg --batch --generate-key bank-batch.txt

# Export public and secret keys in ASCII armored form
gpg --armor --export "Customer Demo" > customer_pub.asc
gpg --armor --export-secret-keys "Customer Demo" > customer_sec.asc

gpg --armor --export "Bank Demo" > bank_pub.asc
gpg --armor --export-secret-keys "Bank Demo" > bank_sec.asc

echo "Generated keys in $(pwd):"
ls -l customer_pub.asc customer_sec.asc bank_pub.asc bank_sec.asc

echo "Done."
