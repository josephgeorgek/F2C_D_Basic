# Scenario: Customer → Bank (PGP/GPG Interop)

**Flow**
- **Customer (Sender)**: *signs* with **Customer PGP private key**, and *encrypts* to **Bank GPG public key**.
- **Bank (Recipient)**: *decrypts* with **Bank GPG private key** and *verifies* with **Customer PGP public key**.

This matches enterprise file-exchange setups: customers sign their files and encrypt for the bank; the bank validates the customer’s signature and decrypts for processing.

## Quick Start (after keys are created)

```bash
# 0) Build
mvn -q -DskipTests package

# 1) Encrypt+Sign as Customer (sender)
java -jar target/pgp-gpg-demo-java-1.0.0.jar encrypt-sign   --in ./customer_to_bank_payload.txt   --out ./out/customer_to_bank_payload.txt.pgp   --enc-pub ./keys/bank_pub.asc   --sign-sec ./keys/customer_sec.asc   --sign-pass "customer-pass"

# 2) Decrypt+Verify as Bank (recipient)
java -jar target/pgp-gpg-demo-java-1.0.0.jar decrypt-verify   --in ./out/customer_to_bank_payload.txt.pgp   --out ./out/customer_to_bank_payload.decrypted   --dec-sec ./keys/bank_sec.asc   --dec-pass "bank-pass"   --verify-pub ./keys/customer_pub.asc
```

> Expected: `Verification OK? true` and decrypted file equals original payload.

## Generate Test Keys (GnuPG)

Run one of the scripts:

- macOS/Linux: `bash ./scripts/gen-keys.sh`
- Windows (PowerShell): `./scripts/gen-keys.bat`

They create:
- `keys/customer_pub.asc`, `keys/customer_sec.asc` (passphrase: `customer-pass`)
- `keys/bank_pub.asc`, `keys/bank_sec.asc` (passphrase: `bank-pass`)

> The scripts are **idempotent** and safe to re-run; they will overwrite existing exported files.
