# Keys for the Customer→Bank Scenario

This directory holds public/secret key exports used by the demo. Generate them with:

```bash
bash ../scripts/gen-keys.sh        # macOS / Linux
# or
./../scripts/gen-keys.bat          # Windows PowerShell/Command Prompt
```

**Identities & Passphrases (for demo only):**
- Customer (sender): uid `Customer Demo <customer@example.com>` — passphrase `customer-pass`
- Bank (recipient): uid `Bank Demo <bank@example.com>` — passphrase `bank-pass`

**Generated files:**
- `customer_pub.asc` — Customer public key (used by Bank to verify signatures)
- `customer_sec.asc` — Customer secret key (used by Customer to sign)
- `bank_pub.asc` — Bank public key (used by Customer to encrypt)
- `bank_sec.asc` — Bank secret key (used by Bank to decrypt)
