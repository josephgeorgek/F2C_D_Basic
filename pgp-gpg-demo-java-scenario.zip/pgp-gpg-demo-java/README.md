# pgp-gpg-demo-java

Java 17 + Maven demo using Bouncy Castle to:

- **Encrypt** with a recipient's **PGP public key** (ASCII-armored `.asc` or binary `.gpg`).
- **Sign** with a sender's **GPG/PGP private key** (secret key) + passphrase.
- **Decrypt** with the recipient's **PGP private key**.
- **Verify** signature with the sender's **public key**.

> Works with keys produced by `gpg` (GnuPG).

## How to run

1) Build

```bash
mvn -q -e -DskipTests package
```

2) Example commands

Assume you have these files:

- `keys/recipient_pub.asc` — recipient public key (for encryption)
- `keys/recipient_sec.asc` — recipient secret key (for decryption)
- `keys/sender_pub.asc` — sender public key (for verify)
- `keys/sender_sec.asc` — sender secret key (for signing)
- Passphrase for `sender_sec.asc` and `recipient_sec.asc`

Encrypt + Sign:

```bash
java -jar target/pgp-gpg-demo-java-1.0.0.jar encrypt-sign   --in ./sample.txt   --out ./sample.txt.pgp   --enc-pub ./keys/recipient_pub.asc   --sign-sec ./keys/sender_sec.asc   --sign-pass "SENDER_PASSPHRASE"
```

Decrypt + Verify:

```bash
java -jar target/pgp-gpg-demo-java-1.0.0.jar decrypt-verify   --in ./sample.txt.pgp   --out ./sample.txt.decrypted   --dec-sec ./keys/recipient_sec.asc   --dec-pass "RECIPIENT_PASSPHRASE"   --verify-pub ./keys/sender_pub.asc
```

## Generate test keys with GPG

```bash
# Generate sender key (interactive; choose RSA 3072+ or ed25519, set passphrase)
gpg --full-generate-key
# Export sender
gpg --armor --export "Your Sender Name" > keys/sender_pub.asc
gpg --armor --export-secret-keys "Your Sender Name" > keys/sender_sec.asc

# Generate recipient key
gpg --full-generate-key
# Export recipient
gpg --armor --export "Your Recipient Name" > keys/recipient_pub.asc
gpg --armor --export-secret-keys "Your Recipient Name" > keys/recipient_sec.asc
```

## Notes

- Uses Bouncy Castle OpenPGP (bcpg/bcprov). Keys created by GPG are supported.
- The demo compresses data, signs a literal data packet, then encrypts the signed data using AES-256.
- Signature type: binary document (`BINARY_DOCUMENT`) with SHA-256.
- Encrypted output is ASCII-armored (`.asc`) by default? **No** – this demo outputs binary `.pgp`. To armor, pass `--armor` flag.
